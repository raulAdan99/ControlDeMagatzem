/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


import com.github.javafaker.Faker;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import org.junit.Assert;
import org.junit.Test;
import utils.Utils;

/**
 *
 * @author ericf
 */
public class UtilsTest {
    Faker faker = new Faker();

    @Test
    public void Test_Regex_data() {
        
        // Definir el formato de fecha esperado
        String format1 = "yyyy/MM/dd";
        DateTimeFormatter f1 = DateTimeFormatter.ofPattern(format1);
        
        // Lista de fechas incorrectas que no deberían pasar la validación
        List<String> incorrectes = new ArrayList<>(Arrays.asList(
                "1-1--2010",
                "41-1-2010",
                "-1-13-2010",
                "-1-1-2010",
                "+1-1-2010",
                "1-1/2010",
                "1/1-2010",
                "1//1/2010",
                "1/1/-2010"));
        
        // Fechas correctas generadas aleatoriamente
        System.out.println("CORRECTES:");
        for (int i = 1; i < 100; i++) {
            // Generar una fecha de cumpleaños aleatoria usando Faker
            Date ok = faker.date().birthday();
            LocalDate lok = LocalDate.ofInstant(ok.toInstant(), ZoneId.systemDefault());
            
            // Formatear la fecha generada en el formato esperado
            String data = f1.format(lok);
            System.out.println(data);
            
            // Verificar que la fecha es válida utilizando el método Utils.stringToLocalDate
            Assert.assertNotNull("La fecha debería ser válida", Utils.stringToLocalDate(data));
        }
        System.out.println();
        
        // Fechas incorrectas que no deberían pasar la validación
        System.out.println("INCORRECTES:");
        for (String s : incorrectes) {
            System.out.println(s);
            
            // Verificar que las fechas incorrectas devuelven null
            Assert.assertNull("La fecha debería ser inválida", Utils.stringToLocalDate(s));
        }
        System.out.println();   
    }
}

