/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


import aplicacio.model.Familia;
import dades.FamiliaDAOImpl;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.TableView;
import javafx.stage.Stage;
import presentacio.FamiliaController;
import utils.RegexUtils;

/**
 *
 * @author ericf
 */
public class TestFamiliaController {
    private FamiliaController controller;
    private FamiliaDAOImpl familiaDAO;
    private Faker faker = new Faker(); // Para generar datos aleatorios

    @Override
    public void start(Stage stage) throws Exception {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Familia.fxml"));
        stage.setScene(new Scene(loader.load()));
        controller = loader.getController();
        familiaDAO = new FamiliaDAOImpl(); // Instancia de DAO para acceder a la BD
        stage.show();
    }

    @Before
    public void setUp() throws Exception {
        // Se ejecuta antes de cada test para inicializar los componentes necesarios
        controller.initialize();  // Inicializar el controlador y cargar los datos
    }

    @Test
    public void testInitialize() throws SQLException {
        // Verificar que los datos fueron cargados correctamente en la tabla
        ObservableList<Familia> familias = controller.tablaVistaFamilia.getItems();
        Assert.assertNotNull(familias);
        Assert.assertTrue(familias.size() > 0);
    }

    @Test
    public void testSelectFamilia() {
        // Simular la selección de una familia en la tabla
        TableView<Familia> tablaFamilia = controller.tablaVistaFamilia;
        Familia familiaSeleccionada = tablaFamilia.getItems().get(0); // Seleccionar la primera familia
        tablaFamilia.getSelectionModel().select(0); // Simular la selección

        // Llamar al método SelectFamilia
        controller.SelectFamilia(null);

        // Verificar que los campos de texto fueron rellenados correctamente
        Assert.assertEquals(String.valueOf(familiaSeleccionada.getId_familia()), controller.ent_id.getText());
        Assert.assertEquals(familiaSeleccionada.getNom(), controller.ent_nom.getText());
        Assert.assertEquals(String.valueOf(familiaSeleccionada.getProveidor_per_defecte()), controller.ent_prove.getText());
        Assert.assertEquals(familiaSeleccionada.getData_alta().format(DateTimeFormatter.ofPattern("dd-MM-yyyy")), controller.ent_alta.getText());
    }

    @Test
    public void testInsertFamilia() throws SQLException {
        // Preparar datos para la inserción
        int Id_familia = faker.number().numberBetween(1000, 9999); // Generar un ID aleatorio
        String Nom = faker.company().name();
        LocalDate Data_alta = LocalDate.now();
        int Proveidor_per_defecte = faker.number().numberBetween(1, 100);
        String Descripcio = faker.lorem().sentence();
        String Observacions = faker.lorem().paragraph();

        // Simular la entrada de datos en los campos de texto
        controller.ent_id.setText(String.valueOf(Id_familia));
        controller.ent_nom.setText(Nom);
        controller.ent_alta.setText(Data_alta.format(DateTimeFormatter.ofPattern("dd-MM-yyyy")));
        controller.ent_prove.setText(String.valueOf(Proveidor_per_defecte));
        controller.ent_des.setText(Descripcio);
        controller.ent_obser.setText(Observacions);

        // Llamar al método para insertar la nueva familia
        controller.insertFamilia();

        // Verificar que la familia fue insertada
        Familia familiaInsertada = familiaDAO.getFamiliaById(Id_familia);
        Assert.assertNotNull(familiaInsertada);
        Assert.assertEquals(Nom, familiaInsertada.getNom());
    }

    @Test
    public void testValidacionFecha() {
        // Caso con una fecha válida
        String fechaValida = "10-10-2023";
        Assert.assertTrue(RegexUtils.isValidDate(fechaValida));

        // Caso con una fecha inválida
        String fechaInvalida = "2023-10-10";
        Assert.assertFalse(RegexUtils.isValidDate(fechaInvalida));
    }
}

