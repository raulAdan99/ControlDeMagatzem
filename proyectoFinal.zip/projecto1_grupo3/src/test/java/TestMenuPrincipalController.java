/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import java.io.IOException;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import org.junit.Assert;
import org.junit.Test;
import org.testfx.framework.junit.ApplicationTest;
import presentacio.MenuPrincipalController;
/**
 *
 * @author ericf
 */
public class TestMenuPrincipalController {
     private MenuPrincipalController controller;
    private Stage stage;

    @Override
    public void start(Stage stage) throws Exception {
        // Cargar el archivo FXML del menú principal
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/menuPrincipal.fxml"));
        Parent root = loader.load();
        controller = loader.getController();
        this.stage = stage;

        // Configurar la escena
        stage.setScene(new Scene(root));
        stage.show();
    }

    @Test
    public void testLogoutButtonFunctionality() {
        // Comprobar que el botón de logout está presente
        Button logoutButton = controller.logoutButton;
        Assert.assertNotNull(logoutButton);

        // Simular clic en el botón de logout
        interact(() -> logoutButton.fire());

        // Verificar que el cambio de escena ocurrió correctamente
        Parent root = stage.getScene().getRoot();
        Assert.assertTrue(root instanceof Parent);

        // Verificar que la escena ahora muestra la interfaz de login
        String sceneFXML = stage.getScene().getRoot().getId();
        Assert.assertEquals("loginRoot", sceneFXML);  // Asegúrate de que la raíz del archivo login.fxml tenga el ID "loginRoot"
    }

    @Test
    public void testSceneChangeAfterLogout() {
        // Simular el clic en el botón de logout
        interact(() -> controller.handleLogout());

        // Verificar que la escena fue reemplazada
        Parent root = stage.getScene().getRoot();
        Assert.assertNotNull(root);

        // Verificar que se cargó correctamente la escena de login
        // Podríamos también verificar el contenido de la nueva escena (opcional)
        Assert.assertTrue(root.getScene().getRoot().getScene() != null);
    }

    @Test
    public void testIOExceptionHandledInLogout() {
        try {
            // Manipular el método para simular una excepción IOException
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/presentacio/login.fxml"));
            when(loader.load()).thenThrow(new IOException());

            // Llamar a handleLogout para verificar que se maneje la excepción
            controller.handleLogout();

            // Si la excepción fue capturada correctamente, el test sigue su curso sin fallar
            Assert.assertTrue("IOException handled successfully", true);

        } catch (IOException e) {
            Assert.fail("IOException should be handled inside handleLogout.");
        }
    }
}