/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


import aplicacio.UsuarioLogic;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import presentacio.LoginController;

/**
 *
 * @author ericf
 */
public class TestLoginController {
    private LoginController controller;
    private UsuarioLogic usuarioLogicMock;

    @Override
    public void start(Stage stage) throws Exception {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/login.fxml"));
        Parent root = loader.load();
        controller = loader.getController();

        // Set up the scene and show the stage
        stage.setScene(new Scene(root));
        stage.show();
    }

    @Before
    public void setUp() throws Exception {
        // Inicializamos un mock de UsuarioLogic para simular la lógica de autenticación
        usuarioLogicMock = Mockito.mock(UsuarioLogic.class);
        controller.usuarioLogic = usuarioLogicMock; // Inyectamos el mock en el controlador
    }

    @Test
    public void testLoginExitoso() throws Exception {
        // Configurar el mock para que retorne verdadero cuando la autenticación es correcta
        when(usuarioLogicMock.authenticateUser("admin", "admin123")).thenReturn(true);

        // Simular entrada de usuario
        interact(() -> {
            controller.txtUsername.setText("admin");
            controller.txtPassword.setText("admin123");
            controller.handleLogin();
        });

        // Verificar que el método de autenticación fue llamado con los parámetros correctos
        verify(usuarioLogicMock).authenticateUser("admin", "admin123");

        // Verificar que el método cargarMenuPrincipal fue llamado correctamente
        // Podemos hacer una verificación visual para comprobar que la ventana cambió a la nueva escena
        Assert.assertNotNull(controller.txtUsername.getScene().getRoot()); // La escena debe estar cargada
    }

    @Test
    public void testLoginFallido() throws Exception {
        // Configurar el mock para que retorne falso cuando la autenticación es incorrecta
        when(usuarioLogicMock.authenticateUser("user", "wrongpass")).thenReturn(false);

        // Simular entrada de usuario
        interact(() -> {
            controller.txtUsername.setText("user");
            controller.txtPassword.setText("wrongpass");
            controller.handleLogin();
        });

        // Verificar que el método de autenticación fue llamado con los parámetros correctos
        verify(usuarioLogicMock).authenticateUser("user", "wrongpass");

        // Verificar que se mostró la alerta de error al fallar el login
        Alert alerta = controller.mostrarAlerta("Error de Login", "Usuario o contraseña incorrectos.", Alert.AlertType.ERROR);
        Assert.assertEquals("Error de Login", alerta.getTitle());
        Assert.assertEquals("Usuario o contraseña incorrectos.", alerta.getContentText());
    }

    @Test
    public void testCargarMenuPrincipal() throws Exception {
        // Simular el inicio de sesión exitoso
        interact(() -> controller.cargarMenuPrincipal());

        // Verificar que la escena fue reemplazada correctamente
        Assert.assertNotNull(controller.txtUsername.getScene().getRoot());
    }
}
