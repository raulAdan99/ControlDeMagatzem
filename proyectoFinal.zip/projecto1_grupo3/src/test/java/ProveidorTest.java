/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import aplicacio.model.Proveidor;
import com.github.javafaker.Faker;
import dades.ProveidorDAO;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import org.junit.Assert;
import org.junit.Test;
import utils.Proveidor;
import utils.MyDataSource;
/**
 *
 * @author ericf
 */
public class ProveidorTest {
    // Instancia de Faker para generar datos aleatorios
    Faker faker = new Faker();

    // Método para probar la inserción de un nuevo proveedor
    @Test
    public void testInsertProveidor() throws SQLException {
        // Generar un CIF único para evitar colisiones
        String uniqueCIF = ProveidorDAO.generateUniqueCIF();

        // Crear un proveedor aleatorio usando Faker
        Proveidor proveidor = new Proveidor(
            0,  // El ID será generado automáticamente
            uniqueCIF,                         // CIF único generado
            faker.number().randomFloat(2, 100, 500), // Precio de transporte
            faker.internet().emailAddress(),    // Email
            LocalDate.now(),                    // Fecha de alta
            faker.company().name(),             // Nombre del proveedor
            faker.bool().bool(),                // Activo/Inactivo
            faker.lorem().sentence(),           // Motivo de inactividad
            faker.number().numberBetween(600000000, 699999999) // Número de teléfono
        );

        // Insertar el proveedor en la base de datos
        ProveidorDAO dao = new ProveidorDAO();
        dao.insertProveidor(proveidor);

        // Verificar que el proveedor fue insertado correctamente
        Proveidor proveidorInsertado = dao.getProveidorById(proveidor.getId());
        Assert.assertNotNull(proveidorInsertado);
        Assert.assertEquals(proveidor.getCIF(), proveidorInsertado.getCIF());
    }

    // Método para probar la actualización de un proveedor existente
    @Test
    public void testUpdateProveidor() throws SQLException {
        ProveidorDAO dao = new ProveidorDAO();
        
        // Obtener un proveedor existente de la base de datos
        Proveidor proveidor = dao.getProveidorById(1); // Asumimos que el ID 1 existe

        // Cambiar algunos valores del proveedor
        String nuevoNombre = faker.company().name();
        float nuevoPrecioTransporte = faker.number().randomFloat(2, 100, 500);
        proveidor.setNom(nuevoNombre);
        proveidor.setPreuTransport(nuevoPrecioTransporte);

        // Actualizar el proveedor en la base de datos
        dao.updateProveidor(proveidor);

        // Verificar si los cambios fueron guardados correctamente
        Proveidor proveidorActualizado = dao.getProveidorById(proveidor.getId());
        Assert.assertEquals(nuevoNombre, proveidorActualizado.getNom());
        Assert.assertEquals(nuevoPrecioTransporte, proveidorActualizado.getPreuTransport(), 0.01);
    }

    // Método para probar la eliminación de un proveedor
    @Test
    public void testDeleteProveidor() throws SQLException {
        ProveidorDAO dao = new ProveidorDAO();

        // Crear un proveedor aleatorio y agregarlo a la base de datos
        String uniqueCIF = ProveidorDAO.generateUniqueCIF();
        Proveidor proveidor = new Proveidor(
            0,
            uniqueCIF,
            faker.number().randomFloat(2, 100, 500),
            faker.internet().emailAddress(),
            LocalDate.now(),
            faker.company().name(),
            faker.bool().bool(),
            faker.lorem().sentence(),
            faker.number().numberBetween(600000000, 699999999)
        );
        dao.insertProveidor(proveidor);

        // Eliminar el proveedor insertado
        dao.deleteProveidor(proveidor);

        // Verificar que el proveedor ha sido eliminado
        Proveidor proveidorEliminado = dao.getProveidorById(proveidor.getId());
        Assert.assertNull(proveidorEliminado);
    }

    // Método para probar la obtención de todos los proveedores
    @Test
    public void testGetAllProveidors() throws SQLException {
        ProveidorDAO dao = new ProveidorDAO();

        // Obtener todos los proveedores
        List<Proveidor> proveidors = dao.getAllProveidor();

        // Verificar que se obtuvieron proveedores
        Assert.assertTrue(proveidors.size() > 0);

        // Imprimir los nombres de los proveedores obtenidos
        proveidors.forEach(proveidor -> System.out.println(proveidor.getNom()));
    }
}
