/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableView;
import javafx.stage.Stage;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.Mockito;
import org.testfx.framework.junit.ApplicationTest;
import aplicacio.model.Proveidor;
import dades.ProveidorDAOImpl;
import presentacio.ProveidorController;
import utils.AlertUtils;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import static org.mockito.Mockito.*;
/**
 *
 * @author ericf
 */
public class TestProveidorController {
    private ProveidorController controller;
    private ProveidorDAOImpl mockProveidorDAO;
    private Stage stage;

    @Override
    public void start(Stage stage) throws Exception {
        // Cargar el archivo FXML del controlador de proveedores
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/proveidor.fxml"));
        Parent root = loader.load();
        controller = loader.getController();
        this.stage = stage;

        // Configurar la escena
        stage.setScene(new Scene(root));
        stage.show();

        // Crear un mock de la clase ProveidorDAOImpl
        mockProveidorDAO = Mockito.mock(ProveidorDAOImpl.class);
        controller.proveidorDAO = mockProveidorDAO;  // Inyectar el mock en el controlador
    }

    @Test
    public void testCargarDatos() throws SQLException {
        // Crear una lista simulada de proveedores
        List<Proveidor> proveidorList = new ArrayList<>();
        proveidorList.add(new Proveidor(1, "CIF001", 500.0f, "email1@example.com", LocalDate.now(), "Proveedor 1", true, "Motivo 1", 123456789));
        proveidorList.add(new Proveidor(2, "CIF002", 600.0f, "email2@example.com", LocalDate.now(), "Proveedor 2", false, "Motivo 2", 987654321));

        // Configurar el mock para devolver esta lista
        when(mockProveidorDAO.getAllProveidor()).thenReturn(proveidorList);

        // Llamar al método cargarDatos() del controlador
        controller.cargarDatos();

        // Verificar que los datos se cargaron en la tabla
        ObservableList<Proveidor> observableList = controller.tableVistaProveidors.getItems();
        Assert.assertEquals(2, observableList.size());
        Assert.assertEquals("Proveedor 1", observableList.get(0).getNom());
        Assert.assertEquals("Proveedor 2", observableList.get(1).getNom());
    }

    @Test
    public void testInsertProveidor() throws SQLException {
        // Simular los campos de texto del controlador
        controller.nomField.setText("Proveedor Nuevo");
        controller.preuField.setText("450.0");
        controller.emailField.setText("nuevo_prov@example.com");
        controller.telefonField.setText("987654321");
        controller.estatField.setSelected(true);
        controller.motiuField.setText("Motivo Nuevo");

        // Simular un nuevo proveedor con CIF generado
        when(mockProveidorDAO.generateUniqueCIF()).thenReturn("CIF003");

        // Llamar al método insertProveidor
        controller.insertProveidor();

        // Verificar que se llamó a la inserción del proveedor con los valores correctos
        verify(mockProveidorDAO, times(1)).insertProveidor(any(Proveidor.class));

        // Verificar que se mostrara el mensaje de éxito
        verifyStatic(AlertUtils.class);
        AlertUtils.showInfoAlert("Éxito", "Proveedor creado correctamente.");
    }

    @Test
    public void testUpdateProveidor() throws SQLException {
        // Crear un proveedor simulado
        Proveidor proveidor = new Proveidor(1, "CIF001", 500.0f, "email@example.com", LocalDate.now(), "Proveedor 1", true, "Motivo 1", 123456789);
        ObservableList<Proveidor> proveidors = FXCollections.observableArrayList(proveidor);
        controller.tableVistaProveidors.setItems(proveidors);

        // Seleccionar el proveedor en la tabla
        controller.tableVistaProveidors.getSelectionModel().select(proveidor);

        // Simular los nuevos valores de los campos de texto
        controller.nomField.setText("Proveedor Actualizado");
        controller.preuField.setText("550.0");
        controller.emailField.setText("actualizado@example.com");
        controller.telefonField.setText("987654321");

        // Llamar al método updateProveidor
        controller.updateProveidor();

        // Verificar que se actualizó el proveedor correctamente
        verify(mockProveidorDAO, times(1)).updateProveidor(any(Proveidor.class));

        // Verificar que se mostró el mensaje de éxito
        verifyStatic(AlertUtils.class);
        AlertUtils.showInfoAlert("Éxito", "Proveedor modificado correctamente.");
    }

    @Test
    public void testDeleteProveidor() throws SQLException {
        // Crear un proveedor simulado
        Proveidor proveidor = new Proveidor(1, "CIF001", 500.0f, "email@example.com", LocalDate.now(), "Proveedor 1", true, "Motivo 1", 123456789);
        ObservableList<Proveidor> proveidors = FXCollections.observableArrayList(proveidor);
        controller.tableVistaProveidors.setItems(proveidors);

        // Seleccionar el proveedor en la tabla
        controller.tableVistaProveidors.getSelectionModel().select(proveidor);

        // Llamar al método deleteProveidor
        controller.deleteProveidor();

        // Verificar que se eliminó el proveedor correctamente
        verify(mockProveidorDAO, times(1)).deleteProveidor(proveidor);

        // Verificar que la tabla ya no contiene el proveedor
        ObservableList<Proveidor> observableList = controller.tableVistaProveidors.getItems();
        Assert.assertFalse(observableList.contains(proveidor));
    }

    @Test
    public void testSelectProveidor() {
        // Crear un proveedor simulado
        Proveidor proveidor = new Proveidor(1, "CIF001", 500.0f, "email@example.com", LocalDate.now(), "Proveedor 1", true, "Motivo 1", 123456789);
        ObservableList<Proveidor> proveidors = FXCollections.observableArrayList(proveidor);
        controller.tableVistaProveidors.setItems(proveidors);

        // Simular la selección del proveedor en la tabla
        controller.tableVistaProveidors.getSelectionModel().select(proveidor);

        // Llamar al método SelectProveidor
        controller.SelectProveidor(null);

        // Verificar que los campos de texto se llenaron con los datos del proveedor
        Assert.assertEquals("CIF001", controller.cifField.getText());
        Assert.assertEquals("Proveedor 1", controller.nomField.getText());
        Assert.assertEquals("email@example.com", controller.emailField.getText());
        Assert.assertEquals("500.0", controller.preuField.getText());
        Assert.assertEquals("123456789", controller.telefonField.getText());
    }
}
