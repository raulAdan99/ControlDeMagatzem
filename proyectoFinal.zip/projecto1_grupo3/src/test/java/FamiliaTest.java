/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import aplicacio.model.Familia;
import com.github.javafaker.Faker;
import dades.FamiliaDAO;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import org.junit.Assert;
import org.junit.Test;
import utils.Familia;
import utils.MyDataSource;
/**
 *
 * @author ericf
 */
public class FamiliaTest {
    // Instancia de Faker para generar datos aleatorios
    Faker faker = new Faker();

    // Método para probar la inserción de una nueva familia
    @Test
    public void testInsertFamilia() throws SQLException {
        // Crear una familia aleatoria usando Faker
        Familia familia = new Familia(
            0, // El ID será generado automáticamente por la base de datos
            faker.company().name(),           // Nombre de la familia
            LocalDate.now(),                  // Fecha de alta (usamos la fecha actual)
            faker.number().numberBetween(1, 10), // Proveedor por defecto (usamos un número aleatorio)
            faker.lorem().sentence(),         // Descripción
            faker.lorem().sentence()          // Observaciones
        );
        
        // Insertar la familia en la base de datos
        FamiliaDAO dao = new FamiliaDAO();
        dao.insertFamilia(familia);

        // Verificar si la familia fue insertada correctamente buscando por el nombre
        Familia familiaInsertada = dao.getFamiliaById(familia.getId_familia());
        Assert.assertNotNull(familiaInsertada);
        Assert.assertEquals(familia.getNom(), familiaInsertada.getNom());
    }

    // Método para probar la actualización de una familia existente
    @Test
    public void testUpdateFamilia() throws SQLException {
        FamiliaDAO dao = new FamiliaDAO();
        
        // Obtener una familia existente de la base de datos
        Familia familia = dao.getFamiliaById(1); // Usamos un ID existente

        // Cambiar algunos datos de la familia
        String nuevoNombre = faker.company().name();
        familia.setNom(nuevoNombre);
        familia.setDescripcio(faker.lorem().sentence());

        // Actualizar la familia en la base de datos
        dao.updateFamilia(familia);

        // Verificar si los cambios fueron guardados correctamente
        Familia familiaActualizada = dao.getFamiliaById(familia.getId_familia());
        Assert.assertEquals(nuevoNombre, familiaActualizada.getNom());
    }

    // Método para probar la eliminación de una familia
    @Test
    public void testDeleteFamilia() throws SQLException {
        FamiliaDAO dao = new FamiliaDAO();
        
        // Crear una nueva familia para eliminar
        Familia familia = new Familia(
            0,
            faker.company().name(),
            LocalDate.now(),
            faker.number().numberBetween(1, 10),
            faker.lorem().sentence(),
            faker.lorem().sentence()
        );
        dao.insertFamilia(familia);

        // Eliminar la familia insertada
        dao.deleteFamilia(familia.getId_familia());

        // Verificar que la familia ya no existe en la base de datos
        Familia familiaEliminada = dao.getFamiliaById(familia.getId_familia());
        Assert.assertNull(familiaEliminada);
    }

    // Método para probar la obtención de todas las familias
    @Test
    public void testGetAllFamilias() throws SQLException {
        FamiliaDAO dao = new FamiliaDAO();

        // Obtener todas las familias
        List<Familia> familias = dao.getAllFamilias();

        // Verificar que se han obtenido familias de la base de datos
        Assert.assertTrue(familias.size() > 0);

        // Imprimir las familias obtenidas
        familias.forEach(familia -> System.out.println(familia.getNom()));
    }
}
