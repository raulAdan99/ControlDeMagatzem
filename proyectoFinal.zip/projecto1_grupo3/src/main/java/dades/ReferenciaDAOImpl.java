/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 * /**
 *
 * @author orjon
 * @author Raul
 */
package dades;

import aplicacio.model.Referencia;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ReferenciaDAOImpl implements ReferenciaDAO {

    // Inserir una nova referència en la base de dades 
    @Override
    public void addReferencia(Referencia referencia) throws SQLException {
        String query = "INSERT INTO referencia (Data_caducitat, Stock, preu_unitari, descripcio, data_alta, Mesos_garantia, Descompte, Id_Familia) "
                + "VALUES (CURRENT_DATE, ?, ?, ?, CURRENT_DATE, ?, ?, ?)";

        try (Connection connection = MyDataSource.getConnection(); PreparedStatement stmt = connection.prepareStatement(query)) {
            // No es necesario establecer el primer parámetro para CURRENT_DATE.
            stmt.setInt(1, referencia.getStock());
            stmt.setFloat(2, referencia.getPreuUnitari());
            stmt.setString(3, referencia.getDescripcio());
            stmt.setInt(4, referencia.getMesosGarantia());
            stmt.setFloat(5, referencia.getDescompte());
            stmt.setInt(6, referencia.getIdFamilia()); // Asegúrate de que este es el 6to parámetro

            stmt.executeUpdate();
        }
    }

    // Obte una referència per el seu ID 
    @Override
    public Referencia getReferenciaById(int idReferencia) throws SQLException {
        String query = "SELECT * FROM referencia WHERE Id_Referencia = ?";
        Referencia referencia = null;

        try (Connection connection = MyDataSource.getConnection(); PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, idReferencia);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    referencia = new Referencia(
                            rs.getObject("Data_caducitat", LocalDate.class),
                            rs.getInt("Id_Referencia"),
                            rs.getInt("Stock"),
                            rs.getFloat("preu_unitari"),
                            rs.getString("descripcio"),
                            rs.getObject("data_alta", LocalDate.class),
                            rs.getInt("Mesos_garantia"),
                            rs.getFloat("Descompte"),
                            rs.getInt("Id_Familia")
                    );
                }
            }
        }
        return referencia;
    }

    // Obte totes les referencies 
    @Override
    public List<Referencia> getAllReferencias() throws SQLException {
        List<Referencia> referencias = new ArrayList<>();
        String query = "SELECT * FROM referencia";

        try (Connection connection = MyDataSource.getConnection(); Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                Referencia referencia = new Referencia(
                        rs.getObject("Data_caducitat", LocalDate.class),
                        rs.getInt("Id_Referencia"),
                        rs.getInt("Stock"),
                        rs.getFloat("preu_unitari"),
                        rs.getString("descripcio"),
                        rs.getObject("data_alta", LocalDate.class),
                        rs.getInt("Mesos_garantia"),
                        rs.getFloat("Descompte"),
                        rs.getInt("Id_Familia")
                );
                referencias.add(referencia);
            }
        }
        return referencias;
    }
    
   /* "INSERT INTO referencia (Data_caducitat, Stock, preu_unitari, descripcio, data_alta, Mesos_garantia, Descompte, Id_Familia) "
                + "VALUES (CURRENT_DATE, ?, ?, ?, CURRENT_DATE, ?, ?, ?)"; */

    // Actualitza una referència existent en la base de dades 
    @Override
    public void updateReferencia(Referencia referencia) throws SQLException {
        String query = "UPDATE referencia SET Data_caducitat = ?, Stock = ?, preu_unitari = ?, descripcio = ?, data_alta = ?, Mesos_Garantia = ?, Descompte = ?, Id_Familia = ? WHERE Id_Referencia = ?";

        try (Connection connection = MyDataSource.getConnection(); PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setObject(1, referencia.getDate_caducitat());
            stmt.setInt(2, referencia.getStock());
            stmt.setFloat(3, referencia.getPreuUnitari());
            stmt.setString(4, referencia.getDescripcio());
            stmt.setObject(5, referencia.getDataAlta());
            stmt.setInt(6, referencia.getMesosGarantia());
            stmt.setFloat(7, referencia.getDescompte());
            stmt.setInt(8, referencia.getIdFamilia());
            stmt.setInt(9, referencia.getIdReferencia());
            stmt.executeUpdate();
        }
    }

    // Eliminar una referencia per el seu ID en la base de dades 
    @Override
    public void deleteReferencia(int idReferencia) throws SQLException {
        String query = "DELETE FROM Referencia WHERE Id_Referencia = ?"; // Asegúrate de que el nombre de la tabla y columna es correcto

        try (Connection connection = MyDataSource.getConnection(); PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, idReferencia); // Usa el Id de la referencia a eliminar
            statement.executeUpdate();
        }
    }
}
