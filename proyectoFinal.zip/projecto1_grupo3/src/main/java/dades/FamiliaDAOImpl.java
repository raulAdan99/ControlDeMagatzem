package dades;

import aplicacio.model.Familia; // Importem la clase Familia 
import java.sql.Connection; // Importem la clase Connection per controlar les connexions a la base de dades 
import java.sql.PreparedStatement; // Importem per executar les consultes SQL 
import java.sql.ResultSet; // Importen per poder controlar el resultat de les consultes 
import java.sql.SQLException; // Importem per controlar els errors de les consultes SQL 
import java.time.LocalDate;
import java.util.ArrayList; // Importem per crear llistes dinamiques 
import java.util.List; // Importem per poder utilitzar la interficie List 

/**
 * Implementació de l'interficie FamiliaDAO. Proporciona els detalls sobre com es reallitzen les operacions 
 * en la base de dades per a les families.
 */
public class FamiliaDAOImpl implements FamiliaDAO {

    // Metode per inertar una nova familia a la base de dades 
    @Override
    public void insertFamilia(Familia familia) throws SQLException {
        // Fem la connexio utilitzant el metode estatic getConnection 
        try (Connection connection = MyDataSource.getConnection()) {
            // Preparem la consulta SQL per insertar una nova familia 
            String sql = "INSERT INTO Familia (Nom,Descripcio,Data_alta,Proveidor_per_defecte,Observacions)" + " VALUES (?, ?, CURRENT_DATE, 1, ?)";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                // Establim els parametres de la consulta 
                statement.setString(1, familia.getNom());
                statement.setObject(2, familia.getDescripcio());
                statement.setString(3, familia.getObservacions());
                // Executem la consulta
                statement.executeUpdate();
            }
        }
    }

    // Metode per actualitzar una familia existent en la base de dades 
    @Override
    public void updateFamilia(Familia familia) throws SQLException {
        // Fem la connexio utilitzant el metode estatic getConnection
        try (Connection connection = MyDataSource.getConnection()) {
            // Preparem la consulta SQL per modificar una familia 
            String sql = "UPDATE Familia SET Nom = ?, Data_alta = ?, Proveidor_per_defecte = ?,Observacions = ?, Descripcio = ? WHERE Id_familia = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                // Establim els parametres de la consulta
                statement.setString(1, familia.getNom());
                statement.setObject(2, familia.getData_alta());
                statement.setInt(3, familia.getProveidor_per_defecte());
                statement.setString(4, familia.getDescripcio());
                statement.setString(5, familia.getObservacions());
                statement.setInt(6, familia.getId_familia());
                // Executem la consulta
                statement.executeUpdate();
            }
        }
    }

    // Método para eliminar una familia de la base de datos
    @Override
    public void deleteFamilia(Familia familia) throws SQLException {
        // Creamos la conexión usando el método estático getConnection
        try (Connection connection = MyDataSource.getConnection()) {
            // Preparamos la consulta SQL para eliminar una familia
            String sql = "DELETE FROM Familia WHERE Id_familia = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                // Establecemos el parámetro de la consulta
                statement.setInt(1, familia.getId_familia());
                // Ejecutamos la consulta
                statement.executeUpdate();
            }
        }
    }

    // Método para obtener una familia de la base de datos por su ID
    @Override
    public Familia getFamiliaById(int Id_familia) throws SQLException {
        Familia familia = null;

        // Creamos la conexión usando el método estático getConnection
        try (Connection connection = MyDataSource.getConnection()) {

            // Preparamos la consulta SQL para obtener una familia por su ID y hacer un JOIN con Proveidor
            String sql = "SELECT f.*, p.Nom AS ProveidorNom FROM Familia f "
                    + "LEFT JOIN Proveidor p ON f.Proveidor_per_defecte = p.Id "
                    + "WHERE f.Id_familia = ?";

            try (PreparedStatement statement = connection.prepareStatement(sql)) {

                // Establecemos el parámetro de la consulta
                statement.setInt(1, Id_familia);

                // Ejecutamos la consulta y obtenemos los resultados
                try (ResultSet resultSet = statement.executeQuery()) {

                    // Si encontramos una familia, la creamos a partir de los resultados
                    if (resultSet.next()) {
                        familia = new Familia(
                                resultSet.getInt("Id_familia"), // ID de la familia
                                resultSet.getString("Nom"), // Nombre de la familia
                                resultSet.getObject("Data_alta", LocalDate.class), // Fecha de alta (DATE)
                                resultSet.getInt("Proveidor_per_defecte"), // ID del proveedor por defecto
                                resultSet.getString("Descripcio"), // Descripción de la familia
                                resultSet.getString("Observacions"), // Observaciones
                                resultSet.getString("ProveidorNom") // Nombre del proveedor (Nuevo campo)
                        );
                    }
                }
            }
        }
        return familia;
    }

    // Método para obtener todas las Familia de la base de datos
    @Override
    public List<Familia> getAllFamilias() throws SQLException {
        List<Familia> familias = new ArrayList<>(); // Inicializamos la lista de familias

        // Creamos la conexión usando el método estático getConnection
        try (Connection connection = MyDataSource.getConnection()) {

            // Preparamos la consulta SQL para obtener todas las familias y el nombre del proveedor por defecto
            String sql = "SELECT f.*, p.Nom AS ProveidorNom "
                    + "FROM Familia f "
                    + "LEFT JOIN Proveidor p ON f.Proveidor_per_defecte = p.Id";

            // Ejecutamos la consulta
            try (PreparedStatement statement = connection.prepareStatement(sql); ResultSet resultSet = statement.executeQuery()) {

                // Iteramos sobre los resultados y creamos objetos Familia
                while (resultSet.next()) {

                    // Construimos el objeto Familia con todos los campos, incluyendo el nombre del proveedor
                    Familia familia = new Familia(
                            resultSet.getInt("Id_familia"), // ID de la familia
                            resultSet.getString("Nom"), // Nombre de la familia
                            resultSet.getObject("Data_alta", LocalDate.class), // Fecha de alta (DATE)
                            resultSet.getInt("Proveidor_per_defecte"), // ID del proveedor por defecto (FOREIGN KEY)
                            resultSet.getString("Descripcio"), // Descripción de la familia
                            resultSet.getString("Observacions"), // Observaciones adicionales
                            resultSet.getString("ProveidorNom") // Nombre del proveedor (desde el JOIN)
                    );

                    // Añadimos la familia a la lista
                    familias.add(familia);
                }
            }
        }

        // Retornamos la lista de familias
        return familias;
    }

    // Método para obtener el nombre de un proveedor por su ID
    public String getProveidorNomById(int idProveidor) throws SQLException {
        String nomProveidor = null;  // Variable para almacenar el nombre del proveedor

        // Creamos la conexión con la base de datos
        try (Connection connection = MyDataSource.getConnection()) {

            // Preparamos la consulta SQL
            String sql = "SELECT Nom FROM Proveidor WHERE Id_proveidor = ?";

            try (PreparedStatement statement = connection.prepareStatement(sql)) {

                // Asignamos el parámetro a la consulta (el ID del proveedor)
                statement.setInt(1, idProveidor);

                // Ejecutamos la consulta
                try (ResultSet resultSet = statement.executeQuery()) {

                    // Si encontramos un resultado, lo asignamos a la variable nomProveidor
                    if (resultSet.next()) {
                        nomProveidor = resultSet.getString("Nom");
                    }
                }
            }
        }

        return nomProveidor;  // Retornamos el nombre del proveedor o null si no existe
    }

    @Override
    public List<Familia> getFamiliasByProveidor(int Id) throws SQLException {
        List<Familia> familias = new ArrayList<>();
        String query = "SELECT * FROM Familia WHERE Proveidor_per_defecte = ?";

        try (Connection connection = MyDataSource.getConnection(); PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, Id);

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                LocalDate localDataAlta = null; // Inicializamos la variable

                // Manejo de null para la fecha
                java.sql.Date dataAlta = rs.getDate("Data_alta");
                if (dataAlta != null) {
                    localDataAlta = dataAlta.toLocalDate();
                }

                Familia familia = new Familia(
                        rs.getInt("Id_familia"),
                        rs.getString("Nom"),
                        localDataAlta, // Usar el valor manejado
                        rs.getInt("Proveidor_per_defecte"),
                        rs.getString("Descripcio"),
                        rs.getString("Observacions"),
                        "" // El nombre del proveedor lo puedes añadir si es necesario
                );
                familias.add(familia);
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener las familias: " + e.getMessage());
            throw e; // Re-lanzar la excepción para manejarla donde se llama
        }

        return familias;
    }

}
