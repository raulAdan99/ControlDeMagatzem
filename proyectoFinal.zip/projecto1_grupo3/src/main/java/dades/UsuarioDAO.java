/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dades;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UsuarioDAO {

    public boolean validateUser(String username, String password) {
        String query = "SELECT * FROM Usuaris WHERE Nom = ? AND Id = ?";

        try (Connection connection = MyDataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setString(1, username);
            statement.setString(2, password);

            ResultSet resultSet = statement.executeQuery();
            return resultSet.next(); // retorna true si hi ha un resultat 
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}