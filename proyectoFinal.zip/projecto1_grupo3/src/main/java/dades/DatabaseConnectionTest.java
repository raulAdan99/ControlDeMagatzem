package dades; 

import java.sql.Connection;
import java.sql.SQLException;

public class DatabaseConnectionTest {
    /*
    public static void main(String[] args) {
        try (Connection connection = MyDataSource.getConnection()) {
            if (connection != null) {
                System.out.println("¡Conexión exitosa a la base de datos!");
            } else {
                System.out.println("¡Fallo al conectar a la base de datos!");
            }
        } catch (SQLException e) {
            System.err.println("Error al intentar conectar a la base de datos:");
            e.printStackTrace();
        }
    } */
} 
//Prova de connexió