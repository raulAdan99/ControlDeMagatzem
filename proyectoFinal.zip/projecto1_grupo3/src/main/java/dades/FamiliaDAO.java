/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dades;

/**
 *
 * @author Raú
 */
import aplicacio.model.Familia;
import java.sql.SQLException;
import java.util.List;

public interface FamiliaDAO {
    void insertFamilia(Familia familia) throws SQLException; // Metode per insertar una nova familia 
    void updateFamilia(Familia familia) throws SQLException; // Metode per actualitzar una familia 
    void deleteFamilia(Familia idFamilia) throws SQLException;    // Metode per eliminar una familia pel ID
    Familia getFamiliaById(int idFamilia) throws SQLException; // Metode per obtenir una familia pel ID 
    List<Familia> getFamiliasByProveidor(int Id) throws SQLException;
    List<Familia> getAllFamilias() throws SQLException;        // metode per obtenir totes les families 
}