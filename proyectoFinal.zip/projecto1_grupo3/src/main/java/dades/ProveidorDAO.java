/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dades;

import aplicacio.model.Proveidor;
import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author Raú
 */

        public interface ProveidorDAO {
    void insertProveidor(Proveidor proveidor) throws SQLException; // Metode per insertar un nou proveidor 
    void updateProveidor(Proveidor proveidor) throws SQLException; // Metode per acyualitzar un proveidor existent 
    void deleteProveidor(Proveidor Id) throws SQLException;    // Metode per eliminar un proveidor existent 
    Proveidor getProveidorById(int Id) throws SQLException; // Metode per obtenir un proveidor pel seu ID 
    List<Proveidor> getAllProveidor() throws SQLException;        // Metode per obtenir tots els proveidors 
    
    
}

