/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dades;
import aplicacio.model.Referencia;
import java.sql.SQLException;
import java.util.List;
/**
 *
 * @author orjon
 */
public interface ReferenciaDAO {
    void addReferencia(Referencia referencia) throws SQLException;
    Referencia getReferenciaById(int idReferencia) throws SQLException;
    List<Referencia> getAllReferencias() throws SQLException;
    void updateReferencia(Referencia referencia) throws SQLException;
    void deleteReferencia(int idReferencia) throws SQLException;
}