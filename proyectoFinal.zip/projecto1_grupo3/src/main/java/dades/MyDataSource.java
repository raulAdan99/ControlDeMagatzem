/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


//@author Raú

package dades;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import java.sql.Connection;
import java.sql.SQLException;

public class MyDataSource {
      
    private static final HikariConfig config = new HikariConfig(); 
    private static HikariDataSource dataSource; 

    //per poder inicialitzar els dos objectes privats ABANS que es cridi l'únic mètode públic getConnection
    static {
        config.setJdbcUrl("jdbc:mysql://localhost/magatzem?useUnicode=true&serverTimezone=Europe/Madrid&allowPublicKeyRetrieval=true&useSSL=false");
        config.setUsername("nuevo_usuario");
        config.setPassword("123456");
        config.addDataSourceProperty("maximumPoolSize", 1); 
        config.addDataSourceProperty("cachePrepStmts", "true");
        config.addDataSourceProperty("prepStmtCacheSize", "250");
        config.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");
        dataSource = new HikariDataSource(config);
    }
     



    public static Connection getConnection() throws SQLException {
        // Retorna una conexión disponible del pool de conexiones
        Connection connection = dataSource.getConnection();
        
        if (connection != null) {
            System.out.println("Conexión establecida exitosamente!");
        } else {
            System.out.println("No se pudo establecer la conexión.");
        }
        
        return connection;
    }
    
    public static void close() {
        if (dataSource != null) {
            dataSource.close();
        }
    }
    
    
    
  
}

