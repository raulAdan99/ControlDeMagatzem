package dades;

import aplicacio.model.Proveidor;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ProveidorDAOImpl implements ProveidorDAO {

    // Inerir un nou proveidor en la base de dades 
    @Override
    public void insertProveidor(Proveidor proveidor) throws SQLException {
        try (Connection connection = MyDataSource.getConnection()) {
            // SQL per inserir un nou proveidor 
            String sql = "INSERT INTO Proveidor (CIF, Preu_de_transport, Email, data_alta, Nom, Actiu_inactiu, Cas_dinactivitat, n_telefon) "
                    + "VALUES (?, ?, ?, CURRENT_DATE, ?, ?, ?, ?)";  // Usamos CURRENT_DATE para la fecha actual

            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                // Establir els valors en el PreparedStatement
                statement.setString(1, proveidor.getCIF()); 
                statement.setFloat(2, proveidor.getPreuTransport());
                statement.setString(3, proveidor.getEmail()); 
                statement.setString(4, proveidor.getNom()); 
                statement.setBoolean(5, proveidor.isActiuInactiu()); 
                statement.setString(6, proveidor.getMotiuInactivitat()); 
                statement.setInt(7, proveidor.getTelefon());

                // Executar la consulta  
                statement.executeUpdate();
            }
        }
    }

    // Actualiza un proveidor existent en la base de dades 
    @Override
    public void updateProveidor(Proveidor proveidor) throws SQLException {
        try (Connection connection = MyDataSource.getConnection()) {
            String sql = "UPDATE Proveidor SET Preu_de_transport = ?, Email = ?, data_alta = ?, Nom = ?, Actiu_inactiu = ?, Cas_dinactivitat = ?, n_telefon = ?,  CIF = ? WHERE Id = ?";

            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setFloat(1, proveidor.getPreuTransport());
                statement.setString(2, proveidor.getEmail());
                statement.setObject(3, proveidor.getDataAlta());
                statement.setString(4, proveidor.getNom());
                statement.setBoolean(5, proveidor.isActiuInactiu());
                statement.setString(6, proveidor.getMotiuInactivitat());
                statement.setInt(7, proveidor.getTelefon());
                statement.setString(8, proveidor.getCIF()); // Canvi per que sigui en 8
                statement.setInt(9, proveidor.getId()); // Afegeix ID igual 

                statement.executeUpdate();
            }
        }
    }

    // Elimina un proveidor de la base de dades pel seu CIF 
    @Override
    public void deleteProveidor(Proveidor proveidor) throws SQLException {
        try (Connection connection = MyDataSource.getConnection()) {
            // Utilitzem ID en la condicio WHERE per eliminar pel IF
            String sql = "DELETE FROM Proveidor WHERE Id = ?";

            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setInt(1, proveidor.getId()); // Utilitzar el ID del objecte Proveidor
                statement.executeUpdate();
            }
        }
    }

    // Obten un proveidor en la base de dades per el seu CIF 
    @Override
    public Proveidor getProveidorById(int Id) throws SQLException {
        Proveidor proveidor = null;

        try (Connection connection = MyDataSource.getConnection()) {
            String sql = "SELECT * FROM Proveidor WHERE Id = ?";

            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setInt(1, Id);

                try (ResultSet resultSet = statement.executeQuery()) {
                    if (resultSet.next()) {
                        proveidor = new Proveidor(
                                resultSet.getInt("Id"),
                                resultSet.getString("CIF"),
                                resultSet.getFloat("Preu_de_transport"),
                                resultSet.getString("Email"),
                                resultSet.getObject("data_alta", LocalDate.class), // Es mante com un String 
                                resultSet.getString("Nom"),
                                resultSet.getBoolean("Actiu_inactiu"),
                                resultSet.getString("Cas_dinactivitat"),
                                resultSet.getInt("n_telefon")
                        );
                    }
                }
            }
        }
        return proveidor;
    }

    // Obten tots els proveidors de la base de dades 
    @Override
    public List<Proveidor> getAllProveidor() throws SQLException {
        List<Proveidor> proveidors = new ArrayList<>();

        try (Connection connection = MyDataSource.getConnection()) {
            String sql = "SELECT * FROM Proveidor";

            try (PreparedStatement statement = connection.prepareStatement(sql); ResultSet resultSet = statement.executeQuery()) {

                while (resultSet.next()) {
                    Proveidor proveidor = new Proveidor(
                            resultSet.getInt("Id"),
                            resultSet.getString("CIF"),
                            resultSet.getFloat("Preu_de_transport"),
                            resultSet.getString("Email"),
                            resultSet.getObject("data_alta", LocalDate.class), // Es mante com String 
                            resultSet.getString("Nom"),
                            resultSet.getBoolean("Actiu_inactiu"),
                            resultSet.getString("Cas_dinactivitat"),
                            resultSet.getInt("n_telefon")
                    );
                    proveidors.add(proveidor);
                }
            }
        }
        return proveidors;
    }

    public static String generateUniqueCIF() throws SQLException {
        String baseCIF = "CIF"; // Base del CIF
        int nextCIF = 0; // Comptador para generar CIF unic 

        // Consulta per obtenir el maxim numero de CIF en la base de dades 
        String sql = "SELECT COALESCE(MAX(CAST(SUBSTRING(CIF, 4) AS UNSIGNED)), 0) FROM Proveidor WHERE CIF LIKE 'CIF%'";
        try (Connection conn = MyDataSource.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {

            if (rs.next()) {
                nextCIF = rs.getInt(1) + 1; // Incrementar el maxim trobat 
            }
        }

        // Retornar el nou CIF
        return baseCIF + String.format("%04d", nextCIF); // Format del CIF amb els ceros a l'esquerra 
    }
}
