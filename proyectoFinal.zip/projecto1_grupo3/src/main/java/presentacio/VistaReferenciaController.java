/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package presentacio;

import javafx.beans.property.*;
import aplicacio.model.Referencia;
import dades.ReferenciaDAOImpl;
import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import utils.AlertUtils;
import utils.RegexUtils;

/**
 *
 * @author orjon
 */
public class VistaReferenciaController {

    @FXML
    private TextField idField;

    @FXML
    private TextField descompteField;

    @FXML
    private TableView<Referencia> tablaReferenciad;

    @FXML
    private TableColumn<Referencia, String> dataAltaColumn;

    @FXML
    private TextField dataCadField;

    @FXML
    private TableColumn<Referencia, String> descColumn;

    @FXML
    private TableColumn<Referencia, Float> preuColumn;

    @FXML
    private TextField stockField;

    @FXML
    private Button modificarButton;

    @FXML
    private TableColumn<Referencia, Float> descompteColumn;

    @FXML
    private TableColumn<Referencia, Integer> stockColumn;

    @FXML
    private TextField dataAltaField;

    @FXML
    private Button sortirButton;

    @FXML
    private TableColumn<Referencia, String> dataCadColumn;

    @FXML
    private TextField descField;

    @FXML
    private TextField mesosField;

    @FXML
    private Button novaButton;

    @FXML
    private TableColumn<Referencia, Integer> idFamiliaColumn;

    @FXML
    private TextField preuField;

    @FXML
    private Button eliminarButton;

    @FXML
    private Button familesButton;

    @FXML
    private TableColumn<Referencia, Integer> IdColumn;

    @FXML
    private TextField idFamiliaField;

    @FXML
    private TableColumn<Referencia, Integer> mesosColumn;

    private ReferenciaDAOImpl ReferenciaDAO = new ReferenciaDAOImpl();
    private ObservableList<Referencia> referenciaObservable; // Lista observable de referencia

    @FXML
    void selectReferencia(MouseEvent event) {
        Referencia selectedReferencia = tablaReferenciad.getSelectionModel().getSelectedItem();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

        if (selectedReferencia != null) {
            idField.setText(String.valueOf(selectedReferencia.getIdReferencia()));
            descField.setText(selectedReferencia.getDescripcio());
            preuField.setText(String.valueOf(selectedReferencia.getPreuUnitari()));
            stockField.setText(String.valueOf(selectedReferencia.getStock()));
            descompteField.setText(String.valueOf(selectedReferencia.getDescompte()));
            mesosField.setText(String.valueOf(selectedReferencia.getMesosGarantia()));
            idFamiliaField.setText(String.valueOf(selectedReferencia.getIdFamilia()));

            String dataAltaStr = selectedReferencia.getDataAlta().format(formatter);
            if (RegexUtils.isValidDate(dataAltaStr)) {
                dataAltaField.setText(dataAltaStr);
            } else {
                dataAltaField.setText("");
                AlertUtils.showErrorAlert("Error de format de data", "La data no té el format vàlid: dd/MM/yyyy.", "Si us plau, torna a escriure-la.");
            }

            String dataCaducitatStr = selectedReferencia.getDate_caducitat() != null ? selectedReferencia.getDate_caducitat().format(formatter) : "";
            if (RegexUtils.isValidDate(dataCaducitatStr)) {
                dataCadField.setText(dataCaducitatStr);
            } else {
                dataCadField.setText("");
                AlertUtils.showErrorAlert("Error de format de data", "La data de caducitat no té el format vàlid: dd/MM/yyyy.", "Si us plau, torna a intentar-ho.");
            }
        }
    }

    @FXML
    public void initialize() throws SQLException {
        // Inicializar la ObservableList
        referenciaObservable = FXCollections.observableArrayList();

        // Configurar les columnes amb les propietats del model Referencia 
        IdColumn.setCellValueFactory(new PropertyValueFactory<>("idReferencia"));
        descColumn.setCellValueFactory(new PropertyValueFactory<>("descripcio"));
        dataAltaColumn.setCellValueFactory(new PropertyValueFactory<>("dataAlta"));
        dataCadColumn.setCellValueFactory(new PropertyValueFactory<>("date_caducitat"));
        preuColumn.setCellValueFactory(new PropertyValueFactory<>("preuUnitari"));
        stockColumn.setCellValueFactory(new PropertyValueFactory<>("stock"));
        descompteColumn.setCellValueFactory(new PropertyValueFactory<>("descompte"));
        mesosColumn.setCellValueFactory(new PropertyValueFactory<>("mesosGarantia"));
        idFamiliaColumn.setCellValueFactory(new PropertyValueFactory<>("idFamilia"));

        // Carrega les dades en la taula
        cargarDatos();

        // Vincular l'event de clic en la taula a la lógica per a seleccionar una referencia
        tablaReferenciad.setOnMouseClicked(event -> {
            selectReferencia(event); // Llama al método SelectReferencia cuando se hace clic en una fila de la tabla
        });
    }

// Método para cargar los datos en la tabla
    private void cargarDatos() throws SQLException {
        // Obtener todas las referencias de la base de datos y agregarlas a la lista observable
        referenciaObservable.setAll(ReferenciaDAO.getAllReferencias());

        // Asignar la lista observable a la tabla
        tablaReferenciad.setItems(referenciaObservable);
    }

    @FXML
    void addReferencia(ActionEvent event) {
        int Id = 0;
        String nom = "";
        String desc = "";
        float preu = 0;
        int stock = 0;
        int mesos = 0;
        float descompte = 0;
        int idFamilia = 1;

        Referencia nuevaReferencia = new Referencia(null, Id, stock, preu, desc, null, mesos, descompte, idFamilia);

        try {
            ReferenciaDAO.addReferencia(nuevaReferencia);
            cargarDatos();
            tablaReferenciad.getSelectionModel().select(nuevaReferencia);
            AlertUtils.showInfoAlert("Èxit", "Referència creada correctament.");
            selectReferencia(null);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void deleteReferencia(ActionEvent event) throws SQLException {
        Referencia selectedReferencia = tablaReferenciad.getSelectionModel().getSelectedItem();
        ReferenciaDAO.deleteReferencia(selectedReferencia.getIdReferencia());
        cargarDatos(); // Recargar los datos en la tabla
    }

    @FXML
    void updateReferencia(ActionEvent event) {
        Referencia selectedReferencia = tablaReferenciad.getSelectionModel().getSelectedItem();

        if (selectedReferencia != null) {
            try {
                String IdStr = idField.getText();
                String stock = stockField.getText();
                String mesos = mesosField.getText();
                String descripcio = descField.getText();
                String preu = preuField.getText().replace(",", ".");
                String dataAltaStr = dataAltaField.getText();
                String dataCadStr = dataCadField.getText();
                String descompte = descompteField.getText().replace(",", ".");
                String idFamilia = idFamiliaField.getText();
                StringBuilder errorMessage = new StringBuilder();

                if (!RegexUtils.isValidId(IdStr)) {
                    errorMessage.append("L'Id ha de ser numèric.\n");
                }

                if (!RegexUtils.isValidId(idFamilia)) {
                    errorMessage.append("L'Id de la família ha de ser numèric.\n");
                }

                if (!RegexUtils.isValidDate(dataAltaStr)) {
                    errorMessage.append("La data d'alta no és vàlida. Format obligatori: dd-MM-yyyy.\n");
                }

                if (!RegexUtils.isValidDate(dataCadStr)) {
                    errorMessage.append("La data de caducitat no és vàlida. Format obligatori: dd-MM-yyyy.\n");
                }

                if (!RegexUtils.isValidFloat(preu)) {
                    errorMessage.append("El preu ha de ser en format decimal (0.0).\n");
                }

                if (!RegexUtils.isValidFloat(descompte)) {
                    errorMessage.append("El descompte ha de ser en format decimal (0.0).\n");
                }

                if (errorMessage.length() > 0) {
                    AlertUtils.showErrorAlert("Errors de validació:", "", errorMessage.toString());
                    return;
                }

                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
                LocalDate dataAlta = LocalDate.parse(dataAltaStr, formatter);
                LocalDate date_caducitat = LocalDate.parse(dataCadStr, formatter);

                selectedReferencia.setIdReferencia(Integer.parseInt(IdStr));
                selectedReferencia.setIdFamilia(Integer.parseInt(idFamilia));
                selectedReferencia.setDataAlta(dataAlta);
                selectedReferencia.setDate_caducitat(date_caducitat);
                selectedReferencia.setPreuUnitari(Float.parseFloat(preu));
                selectedReferencia.setMesosGarantia(Integer.parseInt(mesos));
                selectedReferencia.setDescripcio(descripcio);
                selectedReferencia.setStock(Integer.parseInt(stock));
                selectedReferencia.setDescompte(Float.parseFloat(descompte));

                ReferenciaDAO.updateReferencia(selectedReferencia);
                cargarDatos();
                tablaReferenciad.getSelectionModel().select(selectedReferencia);
                AlertUtils.showInfoAlert("Èxit", "Referència modificada correctament.");

            } catch (SQLException e) {
                e.printStackTrace();
                AlertUtils.showErrorAlert("Error", "No s'ha pogut modificar la referència. Detalls de l'error: ", e.getMessage());
            } catch (NumberFormatException e) {
                e.printStackTrace();
                AlertUtils.showErrorAlert("Error de format", "El valor introduït no és vàlid.", e.getMessage());
            }
        }
    }

    @FXML
    void cambiarAFamilias(ActionEvent event) {

    }

    @FXML
    private void salirAlMenu() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/presentacio/menu.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) sortirButton.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            AlertUtils.showErrorAlert("Error", "No s'ha pogut carregar el menú principal.", e.getMessage());
        }
    }

}
