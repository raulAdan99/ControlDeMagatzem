package presentacio;

/**
 *
 * @author Raú
 */
import aplicacio.model.Proveidor;
import dades.MyDataSource;
import dades.ProveidorDAOImpl;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import utils.AlertUtils;
import utils.RegexUtils;

public class ProveidorController {

    @FXML
    private TableView<Proveidor> tableVistaProveidors;

    @FXML
    private TableColumn<Proveidor, String> dataAltaColumn;

    @FXML
    private TableColumn<Proveidor, String> motiuIColumn;

    @FXML
    private TableColumn<Proveidor, Integer> idColumn;

    @FXML
    private TableColumn<Proveidor, Float> preuTransportColumn;

    @FXML
    private TableColumn<Proveidor, String> emailColumn;

    @FXML
    private TextField cifField;

    @FXML
    private TextField motiuField;

    @FXML
    private TableColumn<Proveidor, String> cifColumn;

    @FXML
    private TextField emailField;

    @FXML
    private Button modificarButton;

    @FXML
    private TableColumn<Proveidor, Boolean> estatColumn;

    @FXML
    private TextField idField;

    @FXML
    private TextField nomField;

    @FXML
    private TextField dataAltaField;

    @FXML
    private Button sortirButton;

    @FXML
    private TableColumn<Proveidor, Integer> telefonColumn;

    @FXML
    private Button novaButton;

    @FXML
    private TextField preuField;

    @FXML
    private TableColumn<Proveidor, String> nomColumn;

    @FXML
    private Button familiesButton;

    @FXML
    private Button elimnarButton;

    @FXML
    private CheckBox estatField;

    @FXML
    private TextField telefonField;

    private ProveidorDAOImpl proveidorDAO = new ProveidorDAOImpl();
    private ObservableList<Proveidor> proveidorsObservable; // Lista observable de proveedores

    @FXML
    void SelectProveidor(MouseEvent event) {
        // Obtenir el proveidor seleccionat 
        Proveidor selectedProveidor = tableVistaProveidors.getSelectionModel().getSelectedItem();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

        if (selectedProveidor != null) {
            // Omplir els camps de text amb les dades del proveidor seleccionat 
            idField.setText(String.valueOf(selectedProveidor.getId()));
            cifField.setText(selectedProveidor.getCIF());
            nomField.setText(selectedProveidor.getNom());
            emailField.setText(selectedProveidor.getEmail());
            String dataAltaStr = selectedProveidor.getDataAlta().format(formatter);

            if (RegexUtils.isValidDate(dataAltaStr)) { // Validar formato de data
                // Si la fecha es válida, mostrarla en el campo de texto
                dataAltaField.setText(dataAltaStr);
            } else {
                // Si la fecha no es válida, mostrar un mensaje de error o dejar el campo vacío
                dataAltaField.setText("");  // Opcional: puedes mostrar un mensaje de error en su lugar
                AlertUtils.showErrorAlert("Error al format de data", "La data no te un format vàlid: dd/MM/yyyy.", "intentalo de nuevo");
            }

            preuField.setText(String.valueOf(selectedProveidor.getPreuTransport()));
            telefonField.setText(String.valueOf(selectedProveidor.getTelefon()));
            estatField.setSelected(selectedProveidor.isActiuInactiu());
            motiuField.setText(selectedProveidor.getMotiuInactivitat());
        }
    }

    @FXML
    public void initialize() throws SQLException {
        // Inicializar la ObservableList
        proveidorsObservable = FXCollections.observableArrayList();

        // Configurar les columnes con les propietats del model Proveidor 
        idColumn.setCellValueFactory(new PropertyValueFactory<>("Id"));
        nomColumn.setCellValueFactory(new PropertyValueFactory<>("nom"));
        cifColumn.setCellValueFactory(new PropertyValueFactory<>("CIF"));
        emailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));
        dataAltaColumn.setCellValueFactory(new PropertyValueFactory<>("dataAlta"));
        estatColumn.setCellValueFactory(new PropertyValueFactory<>("actiuInactiu"));
        motiuIColumn.setCellValueFactory(new PropertyValueFactory<>("motiuInactivitat"));
        telefonColumn.setCellValueFactory(new PropertyValueFactory<>("telefon"));
        preuTransportColumn.setCellValueFactory(new PropertyValueFactory<>("preuTransport"));

        // Carregar les dades en la taula 
        cargarDatos();

        /*
        S'utilitza una expressio lambda per a vincular l'event de click a SelectProveidor(event).
        Aixo permet que el metode controli l'event de click i truqui a la logica que necesita per a sellecionar el proveidor.
         */
        tableVistaProveidors.setOnMouseClicked(event -> {
            SelectProveidor(event); // Truca al metode SelectProveidor
        });

    }

    public void cargarDatos() throws SQLException {
        // Obte la lllista de proveidors desde el servei
        List<Proveidor> proveidors = proveidorDAO.getAllProveidor();  // Capa de servei

        // Neteja la llista observable abans d'afegir noves dades 
        proveidorsObservable.clear();

        // Afegeix els proveidors a la llista observable 
        proveidorsObservable.addAll(proveidors);

        // Assiganr la llista observable a la taula 
        tableVistaProveidors.setItems(proveidorsObservable);
    }

    @FXML
    private void insertProveidor() throws SQLException {
        // Recull dades del camps de text  
        int Id = 0;
        /*Trucada al mètode generateUniqueCIF de la classe DAOimpl 
        de proveïdor per comprovar que no hi ha un nou proveïdor previ i generar un String estil CIF001++*/
        String CIF = "";
        try {
            CIF = dades.ProveidorDAOImpl.generateUniqueCIF();
        } catch (SQLException e) {
            e.printStackTrace(); // Controla l'excepcio adecuadament 
            AlertUtils.showInfoAlert("Error", "No se pudo generar un CIF único.");
            return; // Sortir del metode si hi ha un error
        }
        String nom = "";
        String email = "";
        // LocalDate dataAlta = dataAltaField.getText().isEmpty() ? "" : motiuField.getText();// Se mantiene como String
        float preuTransport = 0;
        boolean actiuInactiu = estatField.isSelected();
        String motiuInactivitat = "";
        int telefon = 0;

        // Crear un nou objecte Proveidor
        Proveidor nuevoProveidor = new Proveidor(Id, CIF, preuTransport, email, null, nom, actiuInactiu, motiuInactivitat, telefon);

        // Intentar insertar el nou proveidor 
        try {
            proveidorDAO.insertProveidor(nuevoProveidor);
            cargarDatos(); // Recargar la llista per mostrar el nou proveidor 
            // Seleccionar el neu proveidor en la tabla
            tableVistaProveidors.getSelectionModel().select(nuevoProveidor);
            AlertUtils.showInfoAlert("Éxito", "Proveedor creat correctament.");
            // Omplir els camps de text amb les dades del nou proveidor 
            SelectProveidor(null); // trucar al metode per reflexar les dades 
        } catch (SQLException e) {
            e.printStackTrace(); // Controlar l'excepcio adecuadament
        }
    }

    @FXML
    private void updateProveidor() {
        // Obtenir el preveidor seleccionat de la taula
        Proveidor selectedProveidor = tableVistaProveidors.getSelectionModel().getSelectedItem();

        // Verificar si se ha seleccionat un proveidor
        if (selectedProveidor != null) {
            try {
                // Validar els camps abans d'actualizar
                String IdStr = idField.getText();
                String email = emailField.getText();
                String CIF = cifField.getText();
                String telefonStr = telefonField.getText();
                String dataAltaStr = dataAltaField.getText();
                StringBuilder errorMessage = new StringBuilder();

                // Validar Id
                if (!RegexUtils.isValidId(IdStr)) {
                    errorMessage.append("Id numèric obligatori.\n");
                }

                // Validar correu electrónic
                if (!RegexUtils.isValidEmail(email)) {
                    errorMessage.append("Correo electrónic no es vàlid.\n");
                }

                // Validar CIF
                if (!RegexUtils.isValidCIF(CIF)) {
                    errorMessage.append("CIF no vàlid.\n");
                }

                // Validar teléfon
                if (!RegexUtils.isValidPhone(telefonStr)) {
                    errorMessage.append("telefon no vàlid\n");
                }

                // Validar la data utilitzant el patró
                if (!RegexUtils.isValidDate(dataAltaStr)) {
                    errorMessage.append("data no vàlida format obligatori: dd-MM-yyyy.\n");
                }

                // Mostrar errors si existeixen
                if (errorMessage.length() > 0) {
                    AlertUtils.showErrorAlert("Errors de validació", "corregeix el següent:", errorMessage.toString());
                    return; // Acabar el metode si hi ha errors
                }

                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
                LocalDate dataAlta = LocalDate.parse(dataAltaStr, formatter);

                // Actualizar les dades del proveidor seleccionat 
                selectedProveidor.setiD(Integer.parseInt(IdStr));
                selectedProveidor.setCIF(cifField.getText());
                selectedProveidor.setNom(nomField.getText());
                selectedProveidor.setEmail(emailField.getText());
                selectedProveidor.setDataAlta(dataAlta);
                selectedProveidor.setPreuTransport(Float.parseFloat(preuField.getText()));
                selectedProveidor.setTelefon(Integer.parseInt(telefonStr));
                selectedProveidor.setActiuInactiu(estatField.isSelected());
                selectedProveidor.setMotiuInactivitat(motiuField.getText());

                // Trucar al mètode del DAO per actualitzar les dades a la base de dades.
                proveidorDAO.updateProveidor(selectedProveidor);
                cargarDatos(); // Recargar los datos en la tabla

                // Seleccionar de nou el proveïdor modificat a la taula.
                tableVistaProveidors.getSelectionModel().select(selectedProveidor);
                AlertUtils.showInfoAlert("Éxito", "Proveedor modificat correctament.");

            } catch (SQLException e) {
                e.printStackTrace(); // Gestionar l'excepció adequadament.
                AlertUtils.showErrorAlert("Error", "No es pot modificar el proveidor. Detalls del error: ", e.getMessage());
            }
        }
    }

    @FXML
    private void deleteProveidor() throws SQLException {

        Proveidor selectedProveidor = tableVistaProveidors.getSelectionModel().getSelectedItem();
        proveidorDAO.deleteProveidor(selectedProveidor);
        cargarDatos(); // Obtener el ID del proveedor seleccionado
    }

    @FXML
    private void cambiarAFamilias() {
        Proveidor selectedProveidor = tableVistaProveidors.getSelectionModel().getSelectedItem();

        if (selectedProveidor != null) {
            // Obtenir l'ID del proveïdor seleccionat.
            int proveedorId = selectedProveidor.getId();

            // Canviar a l'escena de famílies i passar l'ID del proveïdor.
            try {
                // Carregar la nova escena.
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/presentacio/vistaFamilia_1.fxml"));
                Parent root = loader.load();

                // Obtenir el controlador de la nova escena 
                FamiliaControllerProveidor familiaController = loader.getController();

                // Pasar el ID del proveidor al controlador de d¡families
                familiaController.setProveedorId(proveedorId);

                // Mostra la nova escena
                Stage stage = (Stage) familiesButton.getScene().getWindow();
                stage.setScene(new Scene(root));
                stage.show();
            } catch (IOException e) {
                e.printStackTrace();
                AlertUtils.showErrorAlert("Error", "No es pot canviar a la vista de familias: ", "disculpa las molestias.");
            }
        } else {
            AlertUtils.showErrorAlert("Error", "Selecciona un proveidor per continuar.", "disculpa las molestias.");
        }
    }

    @FXML
    public void exportToCSV() {
        // Crear un FileChooser para que el usuario seleccione el destino del archivo
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Guardar archivo CSV");

        // Configurar la extensión del archivo para CSV
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Archivos CSV", "*.csv"));

        // Sugerir un nombre por defecto con timestamp
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        fileChooser.setInitialFileName("proveidors_" + timeStamp + ".csv");

        // Abrir el cuadro de diálogo de guardado y obtener la ubicación seleccionada por el usuario
        Stage stage = new Stage();  // O puedes usar una referencia al Stage de tu aplicación principal
        File file = fileChooser.showSaveDialog(stage);

        if (file != null) {
            try (PrintWriter writer = new PrintWriter(new FileWriter(file)); Connection connection = MyDataSource.getConnection()) {

                // Escribir encabezados
                writer.println("ID,Preu de transport,Email,Data Alta,Nom,CIF,Actiu/Inactiu,Cas d'inactivitat,Telèfon");

                // Obtener los proveedores desde la base de datos
                String query = "SELECT Id, Preu_de_transport, Email, data_alta, Nom, CIF, Actiu_inactiu, Cas_dinactivitat, n_telefon FROM Proveidor";
                try (PreparedStatement stmt = connection.prepareStatement(query); ResultSet rs = stmt.executeQuery()) {

                    while (rs.next()) {
                        int id = rs.getInt("Id");
                        float preuDeTransport = rs.getFloat("Preu_de_transport");
                        String email = rs.getString("Email");
                        Date dataAlta = rs.getDate("data_alta");
                        String nom = rs.getString("Nom");
                        String cif = rs.getString("CIF");
                        boolean actiuInactiu = rs.getBoolean("Actiu_inactiu");
                        String casDinactivitat = rs.getString("Cas_dinactivitat");
                        int telefon = rs.getInt("n_telefon");

                        // Escribir cada proveedor en el archivo CSV
                        writer.println(id + "," + preuDeTransport + "," + email + "," + dataAlta + "," + nom + "," + cif + ","
                                + actiuInactiu + "," + casDinactivitat + "," + telefon);
                    }

                    mostrarAlerta("Dades exportades exitosamente al archivo: " + file.getAbsolutePath(), Alert.AlertType.INFORMATION);
                } catch (SQLException e) {
                    mostrarAlerta("Error al importar les dades: " + e.getMessage(), Alert.AlertType.ERROR);
                }
            } catch (IOException | SQLException e) {
                mostrarAlerta("Error al exportar les dades: " + e.getMessage(), Alert.AlertType.ERROR);
            }
        } else {
            mostrarAlerta("El usuario ha cancelat.", Alert.AlertType.INFORMATION);
        }
    }

    @FXML
    public void importFromCSV() {
        // Fer un FileChooser per a que l'usuari seleccioni l'arxiu CSV
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Seleccionar archivo CSV");

        // Configurar l'extensió permitida per a CSV
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Archivos CSV", "*.csv"));

        // Abrir el cuadro de diálogo de selección de archivos y obtener el archivo seleccionado por el usuario
        Stage stage = new Stage();  // O puedes usar una referencia al Stage de tu aplicación principal
        File file = fileChooser.showOpenDialog(stage);

        if (file != null) {
            try (BufferedReader br = new BufferedReader(new FileReader(file)); Connection connection = MyDataSource.getConnection()) {  // Obtener la conexión de MyDataSource

                String line;
                while ((line = br.readLine()) != null) {
                    String[] values = line.split(",");

                    if (values.length != 9) {  // Confirmar de que hi ha 9 columnes en cada linea 
                        mostrarAlerta("Formato incorrecto en la línea: " + line, Alert.AlertType.WARNING);
                        continue;
                    }

                    int id = Integer.parseInt(values[0]);
                    float preuDeTransport = Float.parseFloat(values[1]);
                    String email = values[2];
                    Date dataAlta = convertirFecha(values[3]);
                    String nom = values[4];
                    String cif = values[5];
                    boolean actiuInactiu = Boolean.parseBoolean(values[6]);
                    String casDinactivitat = values[7];
                    int telefon = Integer.parseInt(values[8]);

                    if (proveidorExists(id, connection)) {
                        mostrarAlerta("Proveedor con ID " + id + " ya existe. ¿Desea actualizarlo?", Alert.AlertType.INFORMATION);
                    } else {
                        insertarProveedor(id, preuDeTransport, email, dataAlta, nom, cif, actiuInactiu, casDinactivitat, telefon, connection);
                        mostrarAlerta("Proveedor insertado correctamente.", Alert.AlertType.INFORMATION);
                    }
                }
            } catch (IOException | SQLException | ParseException e) {
                mostrarAlerta("Error al leer el archivo CSV o insertar datos: " + e.getMessage(), Alert.AlertType.ERROR);
            } catch (NumberFormatException e) {
                mostrarAlerta("Error de formato en algún campo numérico: " + e.getMessage(), Alert.AlertType.ERROR);
            }
        } else {
            mostrarAlerta("El usuario canceló la importación.", Alert.AlertType.INFORMATION);
        }
    }

    private Date convertirFecha(String fecha) throws ParseException {
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");  // Exemple: 25/12/2023
        java.util.Date fechaUtil = formatoFecha.parse(fecha);
        return new Date(fechaUtil.getTime());  // Convertir a java.sql.Date
    }

    private boolean proveidorExists(int id, Connection connection) {
        String query = "SELECT id FROM Proveidor WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                return rs.next(); // si existeix una fila, el proveidor ja hi es en la base de dades 
            }
        } catch (SQLException e) {
            mostrarAlerta("Error al comprobar la existencia del proveedor: " + e.getMessage(), Alert.AlertType.ERROR);
        }
        return false;
    }

    private void insertarProveedor(int id, float preuDeTransport, String email, Date dataAlta, String nom, String cif, boolean actiuInactiu, String casDinactivitat, int telefon, Connection connection) {
        String insertQuery = "INSERT INTO Proveidor (id, Preu_de_transport, Email, data_alta, Nom, CIF, Actiu_inactiu, Cas_dinactivitat, n_telefon) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(insertQuery)) {
            stmt.setInt(1, id);
            stmt.setFloat(2, preuDeTransport);
            stmt.setString(3, email);
            stmt.setDate(4, (java.sql.Date) dataAlta);  // Aqui utilitzem java.sql.Date per inserir la data
            stmt.setString(5, nom);
            stmt.setString(6, cif);
            stmt.setBoolean(7, actiuInactiu);
            stmt.setString(8, casDinactivitat);
            stmt.setInt(9, telefon);
            stmt.executeUpdate();
        } catch (SQLException e) {
            mostrarAlerta("Error al insertar el proveedor: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    // Método para mostrar alertas (pop-up) al usuario
    private void mostrarAlerta(String mensaje, Alert.AlertType tipoAlerta) {
        Alert alerta = new Alert(tipoAlerta);
        alerta.setTitle("Información");
        alerta.setHeaderText(null);  // Elimina el capcalera
        alerta.setContentText(mensaje);
        alerta.showAndWait();  // Mostra el pop-up y espera a que l'usuari el tenqui
    }
    
    @FXML
    private void salirAlMenu() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/presentacio/menu.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) sortirButton.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            AlertUtils.showErrorAlert("Error", "No se pudo cargar el menú principal.", e.getMessage());
        }
    }

}