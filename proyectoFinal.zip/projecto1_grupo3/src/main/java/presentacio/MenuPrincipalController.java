package presentacio;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button; // Importa la clase Button
import javafx.stage.Stage;

import java.io.IOException;

public class MenuPrincipalController {

    @FXML
    private Button logoutButton; // Declara el botó de tancar sesió

    @FXML
    private Button referenciasButton; // Declara el botó de referencies
    @FXML
    private Button proveidorsButton; // Declara el botó de proveïdors
    @FXML
    private Button familiesButton; // Declara el botó de families

    @FXML
    private void initialize() {
        // Inicializa components del menu principal si es necessari
    }

    @FXML
    private void irAReferencias() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/presentacio/vistaReferencia.fxml"));
        Parent root = loader.load();
        // Obtenir el stage desde el boto de referencies 
        Stage stage = (Stage) referenciasButton.getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }

    @FXML
    private void irAProveidors() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/presentacio/vistaProveidors.fxml"));
        Parent root = loader.load();
        // Obtenir el stage desde el boto de proveidors 
        Stage stage = (Stage) proveidorsButton.getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }

    @FXML
    private void irAFamilies() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/presentacio/vistaFamilia.fxml"));
        Parent root = loader.load();
        // Obtenir el stage desde el boto de families
        Stage stage = (Stage) familiesButton.getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }

    @FXML
    private void handleLogout() {
        try {
            // carregar l'arxiu  FXML de login
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/presentacio/Login.fxml"));
            Parent root = loader.load();

            // Obtenir la finestra actual desde el boto de longout 
            Stage stage = (Stage) logoutButton.getScene().getWindow();

            // Reescriure l'escena actual con la del login 
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

