package presentacio;

import aplicacio.UsuarioLogic;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class LoginController {

    @FXML
    private TextField txtUsername; // Camp de text per l'usuari 

    @FXML
    private PasswordField txtPassword; // Camp de contraseña

    @FXML
    private Button confirmButton; // Botó per a confirmar l'inicio de sesió

    @FXML
    private Label messageLabel; // Etiqueta para mostrar missatges

    private UsuarioLogic usuarioLogic;

    public LoginController() {
        usuarioLogic = new UsuarioLogic(); // Inicializar lógica de l'usuari
    }

    @FXML
    public void initialize() {
        // Estableix l'accio del boto  
        confirmButton.setOnAction(event -> handleLogin());
    }

    @FXML
    private void handleLogin() {
        String username = txtUsername.getText();
        String password = txtPassword.getText();

        if (usuarioLogic.authenticateUser(username, password)) {
            cargarMenuPrincipal(); // Carrega directament el menu principal 
        } else {
            mostrarAlerta("Error de Login", "Usuario o contraseña incorrectos.", Alert.AlertType.ERROR);
        }
    }

    private void mostrarAlerta(String titulo, String mensaje, Alert.AlertType tipoAlerta) {
        Alert alerta = new Alert(tipoAlerta);
        alerta.setTitle(titulo);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }

    private void cargarMenuPrincipal() {
        try {
            // Carregar l'arciu FXML de MenuPrincipal
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/presentacio/menu.fxml"));
            Parent root = loader.load();

            // Obtenir la finestra actual
            Stage stage = (Stage) txtUsername.getScene().getWindow();

            // Reescriure l'escena actual amb la del menu principal
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            messageLabel.setText("Error al cargar el menú principal.");
            e.printStackTrace();
        }
    }
}

