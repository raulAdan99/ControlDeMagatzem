/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package presentacio;
/*hola buenas tardes*/
import aplicacio.FamiliaLogic;
import aplicacio.MainApp;
import aplicacio.model.Familia;
import aplicacio.model.Proveidor;
import dades.FamiliaDAOImpl;
import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import utils.AlertUtils;
import utils.RegexUtils;

/**/
public class FamiliaController {

    @FXML
    private TableView<Familia> tablaVistaFamilias;

    @FXML
    private TextField idField;

    @FXML
    private TextField nomProvField;

    @FXML
    private TableColumn<String, LocalDate> dataAltaColumn;

    @FXML
    private TableColumn<Familia, String> descColumn;

    @FXML
    private Button modificarButton;

    @FXML
    private TableColumn<Familia, String> nomProvColumn;

    @FXML
    private TextField nomField;

    @FXML
    private TextField dataAltaField;

    @FXML
    private Button sortirButton;

    @FXML
    private TextField descField;

    @FXML
    private TextField obsField;

    @FXML
    private Button novaButton;

    @FXML
    private TableColumn<Familia, String> nomColumn;

    @FXML
    private HBox ent_prov;

    @FXML
    private Button eliminarButton;

    @FXML
    private TableColumn<Familia, String> obsColumn;

    @FXML
    private Button referenciesButton;

    @FXML
    private TableColumn<Familia, Integer> idColumn;

    private FamiliaDAOImpl FamiliaDAO = new FamiliaDAOImpl();
    private ObservableList<Familia> familiaObservable; // Lista observable de familia 

    @FXML
    public void initialize() throws SQLException {
        // Inicializar la ObservableList
        familiaObservable = FXCollections.observableArrayList();

        // Configurar les columnes amb les propietats del model Familia 
        idColumn.setCellValueFactory(new PropertyValueFactory<>("Id_familia"));
        nomColumn.setCellValueFactory(new PropertyValueFactory<>("Nom"));

        // Asignar els camps de proveidorNom en comptes de Proveidor_per_defecte
        nomProvColumn.setCellValueFactory(new PropertyValueFactory<>("proveidorNom"));

        dataAltaColumn.setCellValueFactory(new PropertyValueFactory<>("Data_alta"));
        descColumn.setCellValueFactory(new PropertyValueFactory<>("Descripcio"));
        obsColumn.setCellValueFactory(new PropertyValueFactory<>("Observacions"));

        // Carrega les dades de la taula
        cargarDatos();

        /*
        S'utilitza una exppressio lambda per vincular l'event de clic a SelectFamilia(event)
        Aixo permet que el metode controli l'event de clic i truqui a la logica que necessita per seleccionar la familia 
        
         */
        tablaVistaFamilias.setOnMouseClicked(event -> {
            SelectFamilia(event); // Truca al metode SelectFamilia(event)
        });

    }

    public void cargarDatos() throws SQLException {
        // Obtenir la llista de families desde el servei
        List<Familia> familias = FamiliaDAO.getAllFamilias();  // Capa de servei

        // Netejar la llista observable abans de afegir noves dades
        familiaObservable.clear();

        // Afegir els proveidors de la llista observable 
        familiaObservable.addAll(familias);

        // Assignar la llista observable per a la taula 
        tablaVistaFamilias.setItems(familiaObservable);
    }

    @FXML
    void SelectFamilia(MouseEvent event) {
        // Obtenir la Familia seleccionada
        Familia selectedFamilia = tablaVistaFamilias.getSelectionModel().getSelectedItem();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

        if (selectedFamilia != null) {
            // Omplir els camps de text amb les dades de Familia seleccionada 
            idField.setText(String.valueOf(selectedFamilia.getId_familia()));
            nomField.setText(selectedFamilia.getNom());

            // no es necessari fer una altra consulta per obtenir el nom de proveidor perque ya el tenim
            String nomProveidor = selectedFamilia.getProveidorNom(); // Accedim directament al nom del proveidor 

            if (nomProveidor != null && !nomProveidor.isEmpty()) {
                //Composar el text amb el nom i ID del proveidor 
                nomProvField.setText(nomProveidor + " (Id: " + selectedFamilia.getProveidor_per_defecte() + ")");
            } else {
                nomProvField.setText(""); // Establir el camp vuit si no es troba el proveidor 
            }

            // Emplenar la data d'alta si existeix 
            if (selectedFamilia.getData_alta() != null) {
                String dataAltaStr = selectedFamilia.getData_alta().format(formatter);
                // Validar format de la data 
                if (RegexUtils.isValidDate(dataAltaStr)) {
                    dataAltaField.setText(dataAltaStr); //Si la data no es valida mostra el camp de text 
                }
            } else {
                dataAltaField.setText(""); // Deixa el camp buit si no hi ha data 
            }

            // Omple els camps de descripció i observacions 
            descField.setText(selectedFamilia.getDescripcio());
            obsField.setText(selectedFamilia.getObservacions()); // o'
        }
    }

    @FXML
    private void insertFamilia() throws SQLException {
        // Recull les dades dels camps de text 

        tablaVistaFamilias.getSelectionModel().clearSelection();

        int id_familia = 0;

        /*Trucada al metode generateUniqueCIF de la classe DAOimpl de proveidor per verificar
        que no hi hagi un nou proveidor d'abans y generar un String estil CIF001 */
        String nom = "";  // Camp buit 
        String Descripcio = ""; // Valor per defecte  
        String Observacions = ""; // Valor per defecte (fals)
        String proveidorNom = ""; // Inicialment buit o assignat mes endevant 

        Familia nuevaFamilia = new Familia(id_familia, nom, null, 0, Descripcio, Observacions, proveidorNom);

        // Fer un nou objecte familia 
        // Intentar afegir el nou proveidor
        try {
            FamiliaDAO.insertFamilia(nuevaFamilia);
            cargarDatos(); // Recargar la lista para mostrar el nuevo proveedor
            // Seleccionar el nou proveidot en la taula 
            tablaVistaFamilias.getSelectionModel().select(nuevaFamilia);
            AlertUtils.showInfoAlert("Éxito", "Proveedor creado correctamente.");
            // Omplir els camps de text amb les dades del neu proveidor 
            SelectFamilia(null); // trucar al metode per reflexar les dades 
        } catch (SQLException e) {
            e.printStackTrace(); // Controlar l'excepcio adecuadament 
        }
    }

    @FXML
    private void deleteFamilia() throws SQLException {

        Familia selectedFamilia = tablaVistaFamilias.getSelectionModel().getSelectedItem();
        FamiliaDAO.deleteFamilia(selectedFamilia);
        cargarDatos(); // Torna a carregar les dades en la taula 
    }

    @FXML
    void updateFamilia(ActionEvent event) {

        Familia selectedFamilia = tablaVistaFamilias.getSelectionModel().getSelectedItem();

        if (selectedFamilia != null) {
            try {
                // Validar els camps abans d'actualitzar 
                String IdStr = idField.getText();
                String nom = nomField.getText();
                String idProv = nomProvField.getText();
                String descStr = descField.getText();
                String obsStr = obsField.getText();
                String dataAltaStr = dataAltaField.getText();

                StringBuilder errorMessage = new StringBuilder();

                // Validar Id
                if (!RegexUtils.isValidId(IdStr)) {
                    errorMessage.append("Id numèric obligatori.\n");
                }
                // Validar Id
                if (!RegexUtils.isValidId(idProv)) {
                    errorMessage.append("El Id de proveidor ha de numeric.\n");
                }

                // Validar la data utilitzant el patró
                if (!RegexUtils.isValidDate(dataAltaStr)) {
                    errorMessage.append("La data no es vàlida. format necesari: dd-MM-yyyy.\n");
                }

                // Veure errors si existeixen
                if (errorMessage.length() > 0) {
                    AlertUtils.showErrorAlert("Errors de validació", "Por favor corrigeix els següents errors:", errorMessage.toString());
                    return; // Finalitza el metode si hi han errors
                }

                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
                LocalDate dataAlta = LocalDate.parse(dataAltaStr, formatter);

                // Actualitzar les dades de la familia seleccionada 
                selectedFamilia.setId_familia(Integer.parseInt(IdStr));
                selectedFamilia.setNom(nomField.getText());
                selectedFamilia.setProveidor_per_defecte(Integer.parseInt(idProv));
                selectedFamilia.setData_alta(dataAlta);
                selectedFamilia.setDescripcio(descField.getText());
                selectedFamilia.setObservacions(obsField.getText());

                // Truca al metode dao per actualitzar les dades en la base de dades 
                FamiliaDAO.updateFamilia(selectedFamilia);
                cargarDatos(); // Torna a carregar les dades en la taula 

                // Seleccionar de nou la familia modificada en la taula 
                tablaVistaFamilias.getSelectionModel().select(selectedFamilia);
                AlertUtils.showInfoAlert("Éxit", "Proveedor modificat correctament.");

            } catch (SQLException e) {
                e.printStackTrace(); // Controlar l'exepcio adecuadament 
                AlertUtils.showErrorAlert("Error", "No es pot modificar el proveïdor. Detalles del error: ", e.getMessage());
            }

        }

    }
    
    @FXML
    private void salirAlMenu() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/presentacio/menu.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) sortirButton.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            AlertUtils.showErrorAlert("Error", "No se pudo carga6r el menú principal.", e.getMessage());
        }
    }
    
    /*
    
     @FXML
    void cambiarAReferencias(ActionEvent event) {
        Familia selectedFamilia = tablaVistaFamilias.getSelectionModel().getSelectedItem();

        if (selectedFamilia != null) {
            try {
                // Cargar la nueva escena de Referencias
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/presentacio/vistaReferencia1.fxml"));
                Parent root = loader.load();

                // Obtener el controlador de la nueva escena (ReferenciaController)
                VistaReferenciaController referenciaController = loader.getController();

                // Pasar el ID de la familia seleccionada al controlador de Referencias
                referenciaController.s);

                // Mostrar la nueva escena
                Stage stage = (Stage) referenciesButton.getScene().getWindow();
                stage.setScene(new Scene(root));
                stage.show();
            } catch (IOException e) {
                e.printStackTrace();
                AlertUtils.showErrorAlert("Error", "No es pot canviar a vista de referencies", "Disculpa las molestias.");
            }
        } else {
            AlertUtils.showErrorAlert("Error", "Selecciona una familia.", " selecciona una familia.");
        }
    }
*/}
