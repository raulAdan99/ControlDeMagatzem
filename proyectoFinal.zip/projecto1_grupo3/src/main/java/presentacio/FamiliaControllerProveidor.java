package presentacio;

import aplicacio.FamiliaLogic;
import aplicacio.MainApp;
import aplicacio.model.Familia;
import aplicacio.model.Proveidor;
import dades.FamiliaDAOImpl;
import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import utils.AlertUtils;
import utils.RegexUtils;

public class FamiliaControllerProveidor {

    @FXML
    private TableView<Familia> tablaVistaFamilias;

    @FXML
    private TextField idField;

    @FXML
    private TextField nomProvField;

    @FXML
    private TableColumn<String, LocalDate> dataAltaColumn;

    @FXML
    private TableColumn<Familia, String> descColumn;

    @FXML
    private Button modificarButton;

    @FXML
    private TableColumn<Familia, String> nomProvColumn;

    @FXML
    private TextField nomField;

    @FXML
    private TextField dataAltaField;

    @FXML
    private Button sortirButton;

    @FXML
    private TextField descField;

    @FXML
    private TextField obsField;

    @FXML
    private Button novaButton;

    @FXML
    private TableColumn<Familia, String> nomColumn;

    @FXML
    private HBox ent_prov;

    @FXML
    private Button eliminarButton;

    @FXML
    private TableColumn<Familia, String> obsColumn;

    @FXML
    private Button referenciesButton;

    @FXML
    private TableColumn<Familia, Integer> idColumn;

    private FamiliaDAOImpl FamiliaDAO = new FamiliaDAOImpl();
    private ObservableList<Familia> familiaObservable; // Lista observable de families 
    private int proveedorId; // ID del proveidor 

    @FXML
    public void initialize() throws SQLException {
        // iniciar la ObservableList
        familiaObservable = FXCollections.observableArrayList();

        // Configurar les columnes amb les propietats del model de familia 
        idColumn.setCellValueFactory(new PropertyValueFactory<>("Id_familia"));
        nomColumn.setCellValueFactory(new PropertyValueFactory<>("Nom"));
        nomProvColumn.setCellValueFactory(new PropertyValueFactory<>("proveidorNom"));
        dataAltaColumn.setCellValueFactory(new PropertyValueFactory<>("Data_alta"));
        descColumn.setCellValueFactory(new PropertyValueFactory<>("Descripcio"));
        obsColumn.setCellValueFactory(new PropertyValueFactory<>("Observacions"));

        // Carregar les dades en la taula  
        cargarDatos();

        // Configurar l'event del click en la taula 
        tablaVistaFamilias.setOnMouseClicked(event -> {
            SelectFamilia(event); // Truca al metode SelectFamilia
        });
    }

    public void setProveedorId(int proveedorId) {
        this.proveedorId = proveedorId; // Estableix el ID del proveidor 
        try {
            cargarDatos(); // Carrega les dades nomes per el proveidor especific
        } catch (SQLException e) {
            e.printStackTrace();
            AlertUtils.showErrorAlert("Error", "No se pudieron cargar los datos para el proveedor seleccionado: ", "pls");
        }
    }

    public void cargarDatos() throws SQLException {
        List<Familia> familias = FamiliaDAO.getAllFamilias(); // Trucada al DAO
        familiaObservable.clear();
        familiaObservable.addAll(familias); // Afegir les families a la llista observable 
        tablaVistaFamilias.setItems(familiaObservable); // Assignar la llista observable a la taula 

        // Opcional: Imprimir totes les dades per a la verificació 
        for (Familia f : familias) {
            System.out.println("Familia: " + f.getNom() + ", Proveedor: " + f.getProveidorNom());
        }
    }

    @FXML
    void SelectFamilia(MouseEvent event) {
        // Obte la Familia seleccionada
        Familia selectedFamilia = tablaVistaFamilias.getSelectionModel().getSelectedItem();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

        if (selectedFamilia != null) {
            // Omple els camps de text amb les dades de la familia seleccionada 
            idField.setText(String.valueOf(selectedFamilia.getId_familia()));
            nomField.setText(selectedFamilia.getNom());

            String nomProveidor = selectedFamilia.getProveidorNom(); // Accedir al nom del proveidor

            if (nomProveidor != null && !nomProveidor.isEmpty()) {
                // Composar el text amb el nom i el Id del proveidor 
                nomProvField.setText(nomProveidor + " (Id: " + selectedFamilia.getProveidor_per_defecte() + ")");
            } else {
                nomProvField.setText(""); // Establir el camp buit si no troba el proveidor 
            }

            // Omple la data d'alta si esta present 
            if (selectedFamilia.getData_alta() != null) {
                String dataAltaStr = selectedFamilia.getData_alta().format(formatter);
                if (RegexUtils.isValidDate(dataAltaStr)) {
                    dataAltaField.setText(dataAltaStr); // Si la data es valida, la mostra en el camp de text 
                }
            } else {
                dataAltaField.setText(""); // Deixa el camp buit si np hi ha data 
            }

            // Omple els camps de la descripcio i observacions 
            descField.setText(selectedFamilia.getDescripcio());
            obsField.setText(selectedFamilia.getObservacions());
        }
    }

    @FXML
    private void insertFamilia() throws SQLException {
        // Recull dades dels camps de text
        tablaVistaFamilias.getSelectionModel().clearSelection();

        int id_familia = 0; // Aquest es genera en la base de dades  
        String nom = ""; // Obte el nom desde el camp de text 
        String Descripcio = ""; // Obte la descripcio 
        String Observacions = ""; // Obte les observacions 

        // Crear un nuevo objeto Familia
        Familia nuevaFamilia = new Familia(id_familia, nom, null, proveedorId, Descripcio, Observacions, ""); // Assignar el ID de la familia 

        // Intentar inserir el nou proveidor 
        try {
            FamiliaDAO.insertFamilia(nuevaFamilia);
            cargarDatos(); // Recarrega la llista per mostrar la nova familia 
            AlertUtils.showInfoAlert("Éxit", "Familia creada correctament.");
        } catch (SQLException e) {
            e.printStackTrace(); // Controlar l'excepcio correctament 
        }
    }

    @FXML
    private void deleteFamilia() throws SQLException {
        Familia selectedFamilia = tablaVistaFamilias.getSelectionModel().getSelectedItem();
        if (selectedFamilia != null) {
            FamiliaDAO.deleteFamilia(selectedFamilia);
            cargarDatos(); // recarrega les dades de la taula 
        } else {
            AlertUtils.showErrorAlert("Error", "Selecciona una familia per eliminar.", "pls");
        }
    }

    @FXML
    void updateFamilia(ActionEvent event) {
        Familia selectedFamilia = tablaVistaFamilias.getSelectionModel().getSelectedItem();

        if (selectedFamilia != null) {
            try {
                String IdStr = idField.getText();
                String nom = nomField.getText();
                String descStr = descField.getText();
                String obsStr = obsField.getText();
                String dataAltaStr = dataAltaField.getText();

                StringBuilder errorMessage = new StringBuilder();

                // Validar Id
                if (!RegexUtils.isValidId(IdStr)) {
                    errorMessage.append("Id numèric obligatori.\n");
                }

                // Validar la data utilitzant el patró
                if (!RegexUtils.isValidDate(dataAltaStr)) {
                    errorMessage.append("La data no es válida. format: dd-MM-yyyy.\n");
                }

                // Mostra errors si existeixen 
                if (errorMessage.length() > 0) {
                    AlertUtils.showErrorAlert("Errors de validació", "Por favor corrigeix els següents errors:", errorMessage.toString());
                    return; // Finalitza el metode si ho ha errors 
                }

                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
                LocalDate dataAlta = LocalDate.parse(dataAltaStr, formatter);

                // Actualizar les dades de la familia seleccionada 
                selectedFamilia.setId_familia(Integer.parseInt(IdStr));
                selectedFamilia.setNom(nom);
                selectedFamilia.setProveidor_per_defecte(proveedorId); // Asignar el ID del proveidor 
                selectedFamilia.setData_alta(dataAlta);
                selectedFamilia.setDescripcio(descStr);
                selectedFamilia.setObservacions(obsStr);

                // Truca al metode DAO per actualitzr les dades en la base de dades  
                FamiliaDAO.updateFamilia(selectedFamilia);
                cargarDatos(); // recarrega les dades en la taula  
                AlertUtils.showInfoAlert("Éxit", "Familia modificada correctament.");

            } catch (SQLException e) {
                e.printStackTrace(); // Controla la excepcio adecuadament 
                AlertUtils.showErrorAlert("Error", "No se es pot modificar la familia. Detalls del error: ", e.getMessage());
            }

        } else {
            AlertUtils.showErrorAlert("Error", "Seleccione una familia per modificar.", "pls");
        }
    }

    @FXML
    private void salirAlMenu() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/presentacio/menu.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) sortirButton.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            AlertUtils.showErrorAlert("Error", "No se pudo cargar el menú principal.", e.getMessage());
        }
    }
}
