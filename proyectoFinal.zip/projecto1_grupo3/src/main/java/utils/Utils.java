/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utils;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

/**
 *
 * @author ericf
 */
public class Utils {
   
    public static LocalDate stringToLocalDate(String Data_alta) {
       // Define el formato personalizado que se espera
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        try {
            // Intentar convertir el String a LocalDate
            return LocalDate.parse(Data_alta, formatter);
        } catch (DateTimeParseException e) {
            // Si el formato es incorrecto o la fecha no es válida, manejar la excepción
            System.out.println("Error: Formato de fecha inválido. Por favor, use el formato dd/MM/yyyy.");
            return null;  // O lanzar una excepción si prefieres
        }
    }
}
