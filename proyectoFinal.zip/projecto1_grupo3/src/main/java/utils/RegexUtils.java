/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Raú
 */




public class RegexUtils {


    // Patró per a validar un ID (nomer números)
    private static final String ID_REGEX = "^[0-9]+$";

    // Patró per a validar un correu electronic
    private static final String EMAIL_REGEX = "^[\\w-\\.]+@[\\w-]+\\.[a-zA-Z]{2,}$";

    // Patró per a validar un nombre de telefon (nomes números y longitud)
    private static final String PHONE_REGEX = "^[0-9]{9,15}$"; // Por ejemplo, de 9 a 15 dígitos

    // Patrón para validar un CIF 
    private static final String CIF_REGEX = "^[ABCDEFGHJNPQRSUVW][0-9]{7}[A-J0-9]$";
    
   private static final String DATE_PATTERN = "^([0-2][0-9]|(3)[0-1])-(0[1-9]|1[0-2])-((19|20)\\d\\d)$";


    public static boolean isValidEmail(String email) {
        return Pattern.matches(EMAIL_REGEX, email);
    }

    public static boolean isValidPhone(String phone) {
        return Pattern.matches(PHONE_REGEX, phone);
    }

    public static boolean isValidCIF(String cif) {
        return Pattern.matches(CIF_REGEX, cif);
    }
    
    public static boolean isValidDate(String date) {
        Pattern pattern = Pattern.compile(DATE_PATTERN);
        Matcher matcher = pattern.matcher(date);
        return matcher.matches();
    }
    
    public static boolean isValidId(String id) {
    return Pattern.matches(ID_REGEX, id);
}
    
    // Patrón para validar un número float (soporta enteros y decimales)
private static final String FLOAT_REGEX = "^[+-]?([0-9]*[.])?[0-9]+$";


public static boolean isValidFloat(String number) {
    return Pattern.matches(FLOAT_REGEX, number);
}
}

