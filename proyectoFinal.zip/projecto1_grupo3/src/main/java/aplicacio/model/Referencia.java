/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aplicacio.model;

import java.time.LocalDate;

/**
 *
 * @author orjon
 * @author raul
 */
public class Referencia {

    private LocalDate date_caducitat;
    private int idReferencia;
    private int stock;
    private float preuUnitari;
    private String descripcio;
    private LocalDate dataAlta;
    private int mesosGarantia;
    private float descompte;
    private int idFamilia;

    

    public Referencia(LocalDate date_caducitat, int idReferencia, int stock, float preuUnitari, String descripcio, LocalDate dataAlta, int mesosGarantia, float descompte, int idFamilia) {

        this.date_caducitat = date_caducitat;
        this.idReferencia = idReferencia;
        this.stock = stock;
        this.preuUnitari = preuUnitari;
        this.descripcio = descripcio;
        this.dataAlta = dataAlta;
        this.mesosGarantia = mesosGarantia;
        this.descompte = descompte;
        this.idFamilia = idFamilia;
        this.dataAlta = dataAlta;
    }


    public Referencia(int aInt, String string, float aFloat, String string0, int aInt0, int aInt1, String dataAlta1, float aFloat0, String string1, int garantiaMeses, float pesUnitari) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
    public LocalDate getDate_caducitat() {
        return date_caducitat;
    }

    public void setDate_caducitat(LocalDate date_caducitat) {
        this.date_caducitat = date_caducitat;
    }

    public int getIdReferencia() {
        return idReferencia;
    }

    public void setIdReferencia(int idReferencia) {
        this.idReferencia = idReferencia;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public float getPreuUnitari() {
        return preuUnitari;
    }

    public void setPreuUnitari(float peuUnitari) {
        this.preuUnitari = peuUnitari;
    }

    public String getDescripcio() {
        return descripcio;
    }

    public void setDescripcio(String descripcio) {
        this.descripcio = descripcio;
    }

    public LocalDate getDataAlta() {
        return dataAlta;
    }

    public void setDataAlta(LocalDate dataAlta) {
        this.dataAlta = dataAlta;
    }

    public int getMesosGarantia() {
        return mesosGarantia;
    }

    public void setMesosGarantia(int mesosGarantia) {
        this.mesosGarantia = mesosGarantia;
    }

    public float getDescompte() {
        return descompte;
    }

    public void setDescompte(float descompte) {
        this.descompte = descompte;
    }

    public int getIdFamilia() {
        return idFamilia;
    }

    public void setIdFamilia(int idFamilia) {
        this.idFamilia = idFamilia;
    }

}

