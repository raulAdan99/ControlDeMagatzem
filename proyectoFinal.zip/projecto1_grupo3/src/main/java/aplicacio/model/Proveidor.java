package aplicacio.model;

import java.time.LocalDate;

public class Proveidor {
    private int Id;
    private String CIF;                      // Codi de indentificacio 
    private float preuTransport;          // Preu del transport 
    private String email;                 // Correu electronic 
    private LocalDate dataAlta;              // Data d'alta 
    private String nom;                   // Nom del proveidor 
    private boolean actiuInactiu;         // Estat del archiu
    private String motiuInactivitat;      // Motiu de inactivitat 
    private int telefon;                  // Numero de telefon

    public Proveidor(int Id, String CIF, float preuTransport, String email, LocalDate dataAlta, String nom, boolean actiuInactiu, String motiuInactivitat, int telefon) {
        this.Id = Id;
        this.CIF = CIF;
        this.preuTransport = preuTransport;
        this.email = email;
        this.dataAlta = dataAlta;
        this.nom = nom;
        this.actiuInactiu = actiuInactiu;
        this.motiuInactivitat = motiuInactivitat;
        this.telefon = telefon;
    }

    public int getId() {
        return Id;
    }
    
    public String getCIF() {
        return CIF;
    }

    public float getPreuTransport() {
        return preuTransport;
    }

    public String getEmail() {
        return email;
    }

    public LocalDate getDataAlta() {
        return dataAlta;
    }

    public String getNom() {
        return nom;
    }

    public boolean isActiuInactiu() {
        return actiuInactiu;
    }

    public String getMotiuInactivitat() {
        return motiuInactivitat;
    }

    public int getTelefon() {
        return telefon;
    }

    public void setCIF(String CIF) {
        this.CIF = CIF;
    }

    public void setPreuTransport(float preuTransport) {
        this.preuTransport = preuTransport;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setDataAlta(LocalDate dataAlta) {
        this.dataAlta = dataAlta;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setActiuInactiu(boolean actiuInactiu) {
        this.actiuInactiu = actiuInactiu;
    }

    public void setMotiuInactivitat(String motiuInactivitat) {
        this.motiuInactivitat = motiuInactivitat;
    }

    public void setTelefon(int telefon) {
        this.telefon = telefon;
    }
    
    public void setiD(int Id) {
        this.Id = Id;
    }
}
