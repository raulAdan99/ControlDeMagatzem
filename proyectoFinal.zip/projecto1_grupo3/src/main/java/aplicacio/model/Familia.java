/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aplicacio.model;

import java.time.LocalDate;
import java.util.List;

/**
 *
 * @author Raú
 */
public class Familia {
    private int Id_familia;
    private String Nom;
    private LocalDate Data_alta;
    private int Proveidor_per_defecte;
    private String Descripcio;
    private String Observacions;
    private String ProveidorNom; // Nou camp per el nom de proveidor

    // Constructor que inclou el nom del proveidor 
    public Familia(int id_familia, String nom, LocalDate data_alta, int proveidor_per_defecte, 
                   String descripcio, String observacions, String proveidorNom) {
        
        
        this.Id_familia = id_familia;
        this.Nom = nom;
        this.Data_alta = data_alta;
        this.Proveidor_per_defecte = proveidor_per_defecte;
        this.Descripcio = descripcio;
        this.Observacions = observacions;
        this.ProveidorNom = proveidorNom;
    }

    // Getter per el nom de proveidor 
    public String getProveidorNom() {
        return ProveidorNom;
    }


    

    public int getId_familia() {
        return Id_familia;
    }

    public void setId_familia(int Id_familia) {
        this.Id_familia = Id_familia;
    }

    public String getNom() {
        return Nom;
    }

    public void setNom(String Nom) {
        this.Nom = Nom;
    }

    public LocalDate getData_alta() {
        return Data_alta;
    }

    public void setData_alta(LocalDate Data_alta) {
        this.Data_alta = Data_alta;
    }

    public int getProveidor_per_defecte() {
        return Proveidor_per_defecte;
    }

    public void setProveidor_per_defecte(int Proveidor_per_defecte) {
        this.Proveidor_per_defecte = Proveidor_per_defecte;
    }

    public String getDescripcio() {
        return Descripcio;
    }

    public void setDescripcio(String Descripcio) {
        this.Descripcio = Descripcio;
    }

    public String getObservacions() {
        return Observacions;
    }

    public void setObservacions(String Observacions) {
        this.Observacions = Observacions;
    }
    
    
}

