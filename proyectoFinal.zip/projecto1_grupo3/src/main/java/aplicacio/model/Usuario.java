package aplicacio.model;

import java.sql.*;
import java.util.ArrayList;
import java.util.Arrays;

public class Usuario {
    /*
    Solo atributos de la bd
     */
    // Datos Usuarios
    protected int id;
    protected String nom;
    protected String rol;
    protected String alta;
    protected String correo;
    protected float salario;
    protected int antiguedad;

    public Usuario(int id, String nom, String rol, String alta, String correo, float salario, int antiguedad) {
        this.id = id;
        this.nom = nom;
        this.rol = rol;
        this.alta = alta;
        this.correo = correo;
        this.salario = salario;
        this.antiguedad = antiguedad;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }

    public String getAlta() {
        return alta;
    }

    public void setAlta(String alta) {
        this.alta = alta;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public float getSalario() {
        return salario;
    }

    public void setSalario(float salario) {
        this.salario = salario;
    }

    public int getAntiguedad() {
        return antiguedad;
    }

    public void setAntiguedad(int antiguedad) {
        this.antiguedad = antiguedad;
    }
}
