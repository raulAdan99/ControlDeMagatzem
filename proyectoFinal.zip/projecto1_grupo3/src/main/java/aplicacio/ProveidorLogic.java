/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aplicacio;

import aplicacio.model.Familia;
import aplicacio.model.Proveidor;
import dades.FamiliaDAO;
import dades.ProveidorDAO;
import dades.ProveidorDAOImpl;
import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author Raú
 */
public class ProveidorLogic {

    final private ProveidorDAO proveidorDAO;

    public ProveidorLogic() {
        // Inicialitzem l'implementacio concreta del DAO
        this.proveidorDAO = new ProveidorDAOImpl();
    }

    public List<Proveidor> obtenirReferencias() throws SQLException {
        
        return proveidorDAO.getAllProveidor();
    }


}
