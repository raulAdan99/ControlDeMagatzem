package aplicacio;

import dades.UsuarioDAO;

public class UsuarioLogic {

    public boolean authenticateUser(String username, String password) {
        UsuarioDAO usuarioDAO = new UsuarioDAO();
        return usuarioDAO.validateUser(username, password);
    }
}
