/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aplicacio;

/**
 *
 * @author ericf
 */
public class excepciones {
    // Excepción personalizada para errores de validación de usuarios
    public static class UsuarioException extends Exception {
        public UsuarioException(String message) {
            super(message);
        }
    }

    // Excepción personalizada para errores relacionados con proveedores
    public static class ProveidorException extends Exception {
        public ProveidorException(String message) {
            super(message);
        }
    }

    // Excepción personalizada para errores relacionados con familias
    public static class FamiliaException extends Exception {
        public FamiliaException(String message) {
            super(message);
        }
    }

    // Excepción para errores de conexión a la base de datos
    public static class DatabaseConnectionException extends Exception {
        public DatabaseConnectionException(String message, Throwable cause) {
            super(message, cause);
        }
    }

    // Excepción para errores de SQL
    public static class SQLExceptionCustom extends Exception {
        public SQLExceptionCustom(String message, Throwable cause) {
            super(message, cause);
        }
    }
}

