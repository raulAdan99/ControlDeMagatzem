/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aplicacio;

import aplicacio.model.Familia;
import dades.FamiliaDAO;
import dades.FamiliaDAOImpl;
import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author ericf
 */
public class FamiliaLogic {
    final private FamiliaDAO familiaDAO;
    
        public FamiliaLogic() {
        // Inicialitzem la implementacio especifica del DAO
        this.familiaDAO = new FamiliaDAOImpl();
    }
        
        public List<Familia> obtenirProveidors() throws SQLException {
        // Aqui podreu aplicar logica de negoci adicional si es necessari 
        return familiaDAO.getAllFamilias();
    }
        
         // Metode per obtenir les families pel ID del proveidor 
    public List<Familia> getFamiliasByProveidor(int Id) throws SQLException {
        // Aqui podreu aplicar la logica adicional si es necessari
        return familiaDAO.getFamiliasByProveidor(Id);
    }
    
}

