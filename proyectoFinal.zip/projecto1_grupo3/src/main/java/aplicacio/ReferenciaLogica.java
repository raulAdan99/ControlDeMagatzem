/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aplicacio;

import aplicacio.model.Referencia;
import dades.ReferenciaDAO;
import dades.ReferenciaDAOImpl;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author Raú
 */
public class ReferenciaLogica {

    private final ReferenciaDAO referenciaDAO;

    public ReferenciaLogica() {
        // Inicialitzem l'implementacio concreta del DAO
        this.referenciaDAO = new ReferenciaDAOImpl();
    }

    public List<Referencia> obtenirProveidors() throws SQLException {

        return referenciaDAO.getAllReferencias();
    }
    // Aqui pots afegir logica adicional si es necessari
}
